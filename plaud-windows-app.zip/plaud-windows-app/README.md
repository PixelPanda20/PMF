# Plaud Recorder für Windows

Windows-Pendant zur Plaud-/Summarizer-App: Aufnahmen vom Plaud-Recorder per
Bluetooth importieren, in einer lokalen Bibliothek verwalten, mit BIT-AI
transkribieren, zusammenfassen und befragen.

Stand: **Etappe 1–3 als Gerüst umgesetzt.** Die plattformunabhängigen Teile
(Kern, BIT-AI-Client, BLE-Protokoll) sind unter Linux gebaut und getestet. Die
Windows-spezifischen Teile (WinUI 3, `Windows.Devices.Bluetooth`, MSIX) konnten
hier nicht kompiliert werden – beim ersten Build auf Windows sind kleinere
Korrekturen zu erwarten.

## Funktionsstand

| Bereich | Status |
|---|---|
| Onboarding (Plaud-Token → Identität) | umgesetzt, Bibliothek getestet |
| BLE-Scan/Connect/Unlock/Handshake | umgesetzt (Windows-Transport, ungetestet) |
| Session-Liste, Download mit Resume, Ogg-Prüfung | umgesetzt (Protokoll getestet) |
| Bibliothek: Liste, Suche, Player, Löschen | umgesetzt |
| Transkription über BIT-AI-STT | umgesetzt, getestet |
| Zusammenfassung (5 Vorlagen), Fragen zum Transkript | umgesetzt, getestet |
| Einstellungen (BIT-AI), API-Key im Credential Locker | umgesetzt |
| Tags, Markdown-Export, Transkript bearbeiten | **offen** (Tabellen vorhanden) |
| MSIX-Paket | Manifest/Assets vorhanden, Signierung offen |

## Projekte

```
src/Plaud.Core            Modelle, SQLite-Bibliothek, Import-Pipeline (net8.0)
src/Plaud.BitAi           Whisper-/Chat-Client, Prompts, Vorlagen (net8.0)
src/Plaud.Ble.Protocol    Protokoll 20: Framing, ChaCha20(-Poly1305), Ogg,
                          RSA-Unlock, PLAUD.AI-Dateien, Transfer-Assembler
src/Plaud.Ble.Windows     Windows.Devices.Bluetooth-Transport
src/PlaudOnboarding       Provisionierung (identisch zum Swift-Paket)
src/PlaudOnboarding.ViewModels
src/Plaud.App             WinUI 3 Shell (Bibliothek, Gerät, Einstellungen,
                          Onboarding) + MSIX-Manifest
tests/Plaud.Tests         xUnit (26 Tests)
```

## Build auf Windows

Voraussetzungen: Windows 10 1809+, .NET 8 SDK, Visual Studio 2022 mit
„Windows App SDK“-Workload.

```powershell
# Bibliothek + Tests (plattformunabhängig)
dotnet test tests\Plaud.Tests\Plaud.Tests.csproj

# App (Windows)
dotnet build src\Plaud.App\Plaud.App.csproj -p:Platform=x64
```

Oder `Plaud.Windows.App.sln` in Visual Studio öffnen und `Plaud.App` starten.
Beim ersten Build ggf. die Windows-App-SDK-Runtime installieren.

## MSIX

`src/Plaud.App/Package.appxmanifest` ist vorbereitet (Capabilities
`internetClient`, `bluetooth`, `runFullTrust`). Der Publisher
`CN=Pascal Gassner BIT` muss zum Signaturzertifikat passen. In Visual Studio:
*Projekt → Publish → Create App Packages*, oder mit `signtool` signieren.

## Konfiguration

- **BIT-AI**: Einstellungen → Base-URL (z. B. `https://…/v1`), API-Key,
  STT-Modell (`whisper-1`), Chat-Modell. Der Key liegt im Windows Credential
  Locker, nicht in SQLite.
- **Plaud-Identität**: Gerät → „Plaud-Konto einrichten“ (Token, Seriennummer,
  Bind-Token). Die `identity.json` liegt unter
  `%LOCALAPPDATA%\PlaudRecorder\identity.json`.
- **Daten**: `%LOCALAPPDATA%\PlaudRecorder\` (SQLite `plaud.db`, `audio/`).

## Sicherheit

- Die Identität enthält den RSA-Private-Key und ist damit so sensibel wie ein
  Passwort. Sie verlässt das Gerät nicht.
- Der BIT-AI-Key liegt im Credential Locker; er wird nicht geloggt.
- Audio und Transkripte bleiben lokal; nur Audio geht an den BIT-AI-STT, nur
  Transkript/Notizen an das Chat-Modell.
- Der `pld_ut`-Token wird nur für die Provisionierung verwendet und nicht
  gespeichert.

## Tests

```bash
dotnet test tests/Plaud.Tests/Plaud.Tests.csproj
```

26 Tests: SQLite-Bibliothek/Suche/Tags, Import-Pipeline, BIT-AI-Client
(Multipart, Chat, langer Text, Fehler), ChaCha20/RFC-8439, Session-Cipher mit
Replay-Schutz, Ogg-CRC, Paketparser, RSA-Unlock, PLAUD.AI-Datei,
Transfer-Assembler.

## Offene Punkte (nächste Etappe)

1. Erster Windows-Build: XAML-/WinRT-Korrekturen, BLE-Test mit Gerät.
2. Tags-UI, Markdown-Export, Transkript bearbeiten.
3. Aufnahme-Detailseite mit Vorlagenwechsel/Re-Runs.
4. MSIX-Signierung und Update-Kanal.
5. Optional: Auto-Import (Gerät in Reichweite → Sessions übernehmen).
