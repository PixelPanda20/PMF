using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;

namespace Plaud.Ble.Protocol;

/// <summary>
/// Server-equivalent RSA steps, run locally by the Windows app: the Plaud
/// identity private key stays in %LOCALAPPDATA% and is never sent anywhere.
/// </summary>
public static class IdentityUnlock
{
    public static SessionKeys DecryptSessionSecret(string privateKeyPem, byte[] secret)
    {
        byte[] plain;
        try
        {
            using var rsa = RSA.Create();
            rsa.ImportFromPem(privateKeyPem);
            plain = rsa.Decrypt(secret, RSAEncryptionPadding.Pkcs1);
        }
        catch (CryptographicException error)
        {
            throw new ProtocolException(
                $"Session-Secret liess sich nicht entschlüsseln: {error.Message}");
        }

        if (plain.Length < 56 + 16)
        {
            throw new ProtocolException("Session-Secret zu kurz");
        }

        var key = plain[..32];
        var nonce = plain[32..44];
        var aad = plain[44..56];
        var payload = plain[56..];
        var ciphertext = payload[..^16];
        var tag = payload[^16..];
        var check = new byte[ciphertext.Length];

        try
        {
            using var aead = new ChaCha20Poly1305(key);
            aead.Decrypt(nonce, ciphertext, tag, check, aad);
        }
        catch (CryptographicException error)
        {
            throw new ProtocolException($"Session-Check fehlgeschlagen: {error.Message}");
        }

        if (Encoding.ASCII.GetString(check) != "PLAUD.AI")
        {
            throw new ProtocolException("Session-Check fehlgeschlagen");
        }
        return new SessionKeys(key, nonce, aad);
    }

    /// <summary>Decrypts a PLAUD.AI recording file (E2EE), returning Ogg bytes.</summary>
    public static byte[] DecryptPlaudFile(string privateKeyPem, byte[] file)
    {
        if (file.Length < 512 || Encoding.ASCII.GetString(file, 0, 8) != "PLAUD.AI")
        {
            throw new ProtocolException("keine PLAUD.AI-Datei");
        }
        var version = BinaryPrimitives.ReadUInt16LittleEndian(file.AsSpan(8));
        var headerSize = BinaryPrimitives.ReadUInt16LittleEndian(file.AsSpan(10));
        if (version != 1)
        {
            throw new ProtocolException($"nicht unterstützte Header-Version {version}");
        }
        if (file.Length < headerSize)
        {
            throw new ProtocolException("Datei kürzer als der Header");
        }

        var counter = BinaryPrimitives.ReadUInt32LittleEndian(file.AsSpan(128));
        var nonce = file[132..144];
        var wrapped = file[256..512];

        byte[] key;
        try
        {
            using var rsa = RSA.Create();
            rsa.ImportFromPem(privateKeyPem);
            key = rsa.Decrypt(wrapped, RSAEncryptionPadding.Pkcs1);
        }
        catch (CryptographicException error)
        {
            throw new ProtocolException($"Inhalts-Schlüssel nicht entschlüsselbar: {error.Message}");
        }

        if (key.Length < 32)
        {
            throw new ProtocolException("Inhalts-Schlüssel zu kurz");
        }
        key = key[^32..];

        var iv = new byte[16];
        BinaryPrimitives.WriteUInt32LittleEndian(iv, counter);
        nonce.CopyTo(iv, 4);

        return ChaCha20.Transform(key, nonce, counter, file.AsSpan(headerSize));
    }
}

/// <summary>Reassembles data packets, skipping retransmits and flagging gaps.</summary>
public sealed class TransferAssembler
{
    private readonly List<byte[]> _chunks = new();

    public uint Expected { get; private set; }

    public bool Add(uint offset, byte[] chunk)
    {
        if (offset < Expected)
        {
            return false; // duplicate after a resume
        }
        if (offset > Expected)
        {
            throw new TransferGapException(Expected);
        }
        _chunks.Add(chunk);
        Expected += (uint)chunk.Length;
        return true;
    }

    public byte[] ToArray()
    {
        var output = new byte[_chunks.Sum(chunk => chunk.Length)];
        var position = 0;
        foreach (var chunk in _chunks)
        {
            chunk.CopyTo(output, position);
            position += chunk.Length;
        }
        return output;
    }
}

public sealed class TransferGapException : Exception
{
    public uint Expected { get; }

    public TransferGapException(uint expected)
        : base($"Datenlücke bei Offset {expected}")
    {
        Expected = expected;
    }
}
