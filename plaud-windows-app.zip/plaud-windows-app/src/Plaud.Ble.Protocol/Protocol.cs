using System.Buffers.Binary;

namespace Plaud.Ble.Protocol;

/// <summary>
/// Plaud protocol 20 framing. Values mirror the reference implementation
/// (`plaud-summarizer/backend/app/ble/protocol.py`); no new protocol is invented.
/// </summary>
public static class PlaudProtocol
{
    public const string ServiceUuid = "00001910-0000-1000-8000-00805f9b34fb";
    public const string NotifyUuid = "00002bb0-0000-1000-8000-00805f9b34fb";
    public const string WriteUuid = "00002bb1-0000-1000-8000-00805f9b34fb";

    public const int CmdHandshake = 1;
    public const int CmdGetSsn = 2;
    public const int CmdGetRecSessions = 26;
    public const int CmdSyncFileStart = 28;
    public const int CmdSyncFileTail = 29;

    public const int FeSignature = 0xfe10;
    public const int FePubkeyRequest = 0xfe11;
    public const int FePubkey = 0xfe12;
    public const int EccFe30 = 0xfe30;

    public const uint EndOfData = 0xffffffff;
    public const int DefaultPortVersion = 20;

    public static byte[] Command(int id, params byte[][] parts)
    {
        var length = 3 + parts.Sum(part => part.Length);
        var packet = new byte[length];
        packet[0] = 1;
        BinaryPrimitives.WriteUInt16LittleEndian(packet.AsSpan(1), (ushort)id);
        var offset = 3;
        foreach (var part in parts)
        {
            part.CopyTo(packet, offset);
            offset += part.Length;
        }
        return packet;
    }

    public static byte[] U16(int value) =>
        new[] { (byte)(value & 0xff), (byte)((value >> 8) & 0xff) };

    public static byte[] U32(uint value)
    {
        var bytes = new byte[4];
        BinaryPrimitives.WriteUInt32LittleEndian(bytes, value);
        return bytes;
    }

    public static byte[] HandshakePacket(string bindToken, int portVersion = DefaultPortVersion, bool second = false)
    {
        var width = portVersion >= 9 ? 32 : 16;
        var token = (bindToken ?? string.Empty).PadRight(width, '0');
        if (token.Length > width)
        {
            token = token[..width];
        }
        var body = portVersion >= 3
            ? new byte[] { 2, 0, (byte)(second ? 1 : 0) }
            : new byte[] { 2, 0 };
        return Command(CmdHandshake, body, System.Text.Encoding.ASCII.GetBytes(token));
    }

    public static byte[] SessionListRequest(uint now, uint startSession = 0, byte flag = 0) =>
        Command(CmdGetRecSessions, U32(now), U32(startSession), new[] { flag });

    public static byte[] SyncStart(uint sessionId, uint start, uint end) =>
        Command(CmdSyncFileStart, U32(sessionId), U32(start), U32(end));

    public static int ReadU16(ReadOnlySpan<byte> data, int offset) =>
        BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(offset));

    public static uint ReadU32(ReadOnlySpan<byte> data, int offset) =>
        BinaryPrimitives.ReadUInt32LittleEndian(data.Slice(offset));

    public static PlaudHandshake ParseHandshake(ReadOnlySpan<byte> packet)
    {
        if (packet.Length < 6 || packet[0] != 1)
        {
            throw new ProtocolException("kein Handshake-Response");
        }
        return new PlaudHandshake(
            Status: packet[3],
            PortVersion: ReadU16(packet, 4),
            Channels: packet.Length > 8 ? packet[8] : (byte)1,
            OggAudio: packet.Length > 11 && packet[11] == 1);
    }

    public static SessionList ParseSessionList(ReadOnlySpan<byte> packet, int portVersion)
    {
        if (packet.Length < 11 || packet[0] != 1)
        {
            throw new ProtocolException("kein Session-Listen-Paket");
        }
        var total = ReadU16(packet, 7);
        var index = ReadU16(packet, 9);
        var size = portVersion == 1 ? 8 : portVersion <= 6 ? 9 : 10;
        var entries = new List<SessionEntry>();
        for (var offset = 11; offset + size <= packet.Length; offset += size)
        {
            entries.Add(
                new SessionEntry(
                    SessionId: ReadU32(packet, offset),
                    Size: ReadU32(packet, offset + 4)));
        }
        return new SessionList(total, index, entries);
    }

    public static DataPacket? ParseDataPacket(ReadOnlySpan<byte> packet, int portVersion, uint expectedSession)
    {
        if (packet.Length < 6 || packet[0] != 2)
        {
            return null;
        }
        var index = 1;
        if (portVersion >= 7)
        {
            if (packet.Length < 10 || ReadU32(packet, 1) != expectedSession)
            {
                return null;
            }
            index = 5;
        }
        var offset = ReadU32(packet, index);
        if (offset == EndOfData)
        {
            return null;
        }
        var length = packet[index + 4];
        if (index + 5 + length > packet.Length)
        {
            return null;
        }
        return new DataPacket(offset, packet.Slice(index + 5, length).ToArray());
    }
}

public sealed record PlaudHandshake(byte Status, int PortVersion, byte Channels, bool OggAudio);

public sealed record SessionEntry(uint SessionId, uint Size);

public sealed record SessionList(int Total, int Index, IReadOnlyList<SessionEntry> Entries);

public sealed record DataPacket(uint Offset, byte[] Chunk);

public sealed class ProtocolException : Exception
{
    public ProtocolException(string message)
        : base(message)
    {
    }
}
