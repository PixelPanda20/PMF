using System.Buffers.Binary;
using System.Security.Cryptography;

namespace Plaud.Ble.Protocol;

/// <summary>
/// Protocol-20 session encryption (ChaCha20-Poly1305 over every packet).
///
/// The device reuses a fixed 12-byte nonce and puts the sequence number in the
/// plaintext, so the AEAD's usual nonce-uniqueness rule is violated by the
/// device protocol itself. This is the reference behaviour; do not "fix" it.
/// </summary>
public sealed class SessionCipher
{
    private readonly ChaCha20Poly1305 _aead;
    private readonly byte[] _nonce;
    private readonly byte[] _associatedData;

    public uint TxSequence { get; private set; } = 1;
    public uint RxSequence { get; private set; } = 0; // first packet uses 2

    public SessionCipher(byte[] key, byte[] nonce, byte[] associatedData)
    {
        if (key.Length != 32 || nonce.Length != 12)
        {
            throw new ProtocolException("ungültige Session-Schlüssellängen");
        }
        _aead = new ChaCha20Poly1305(key);
        _nonce = nonce;
        _associatedData = associatedData;
    }

    public byte[] Encrypt(ReadOnlySpan<byte> packet)
    {
        TxSequence++;
        var plaintext = new byte[4 + packet.Length];
        BinaryPrimitives.WriteUInt32LittleEndian(plaintext, TxSequence);
        packet.CopyTo(plaintext.AsSpan(4));

        var ciphertext = new byte[plaintext.Length];
        var tag = new byte[16];
        _aead.Encrypt(_nonce, plaintext, ciphertext, tag, _associatedData);

        var output = new byte[ciphertext.Length + tag.Length];
        ciphertext.CopyTo(output, 0);
        tag.CopyTo(output, ciphertext.Length);
        return output;
    }

    public byte[] Decrypt(ReadOnlySpan<byte> data)
    {
        if (data.Length < 16 + 4)
        {
            throw new ProtocolException("Paket zu kurz");
        }

        var ciphertext = data[..^16].ToArray();
        var tag = data[^16..].ToArray();
        var plaintext = new byte[ciphertext.Length];
        try
        {
            _aead.Decrypt(_nonce, ciphertext, tag, plaintext, _associatedData);
        }
        catch (CryptographicException error)
        {
            throw new ProtocolException($"Paket nicht entschlüsselbar: {error.Message}");
        }

        var sequence = BinaryPrimitives.ReadUInt32LittleEndian(plaintext);
        if (sequence <= RxSequence)
        {
            throw new ProtocolException($"Replay-Sequenz {sequence}");
        }
        RxSequence = sequence;
        return plaintext[4..];
    }
}

/// <summary>The session material returned by the RSA unlock.</summary>
public sealed record SessionKeys(byte[] Key, byte[] Nonce, byte[] AssociatedData);
