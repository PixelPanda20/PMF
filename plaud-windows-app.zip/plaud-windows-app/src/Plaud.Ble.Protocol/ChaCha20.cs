using System.Buffers.Binary;

namespace Plaud.Ble.Protocol;

/// <summary>
/// Raw ChaCha20 (RFC 8439) for the PLAUD.AI file container. The AEAD class in
/// .NET only exposes ChaCha20-Poly1305, so the keystream is implemented here
/// and checked against the RFC test vector.
/// </summary>
public static class ChaCha20
{
    public static byte[] Transform(byte[] key, byte[] nonce, uint counter, ReadOnlySpan<byte> input)
    {
        if (key.Length != 32 || nonce.Length != 12)
        {
            throw new ProtocolException("ungültige ChaCha20-Schlüssellängen");
        }

        var output = new byte[input.Length];
        var state = new uint[16];
        state[0] = 0x61707865;
        state[1] = 0x3320646e;
        state[2] = 0x79622d32;
        state[3] = 0x6b206574;
        for (var i = 0; i < 8; i++)
        {
            state[4 + i] = BinaryPrimitives.ReadUInt32LittleEndian(key.AsSpan(i * 4));
        }
        state[12] = counter;
        for (var i = 0; i < 3; i++)
        {
            state[13 + i] = BinaryPrimitives.ReadUInt32LittleEndian(nonce.AsSpan(i * 4));
        }

        var block = new byte[64];
        var blockCounter = counter;
        for (var offset = 0; offset < input.Length; offset += 64)
        {
            Block(state, blockCounter, block);
            blockCounter++;
            var length = Math.Min(64, input.Length - offset);
            for (var i = 0; i < length; i++)
            {
                output[offset + i] = (byte)(input[offset + i] ^ block[i]);
            }
        }
        return output;
    }

    private static void Block(uint[] initial, uint counter, byte[] output)
    {
        // The final addition must use the state with THIS block's counter,
        // not the starting counter of the keystream.
        var baseState = (uint[])initial.Clone();
        baseState[12] = counter;
        var working = (uint[])baseState.Clone();

        for (var round = 0; round < 10; round++)
        {
            QuarterRound(working, 0, 4, 8, 12);
            QuarterRound(working, 1, 5, 9, 13);
            QuarterRound(working, 2, 6, 10, 14);
            QuarterRound(working, 3, 7, 11, 15);
            QuarterRound(working, 0, 5, 10, 15);
            QuarterRound(working, 1, 6, 11, 12);
            QuarterRound(working, 2, 7, 8, 13);
            QuarterRound(working, 3, 4, 9, 14);
        }

        for (var i = 0; i < 16; i++)
        {
            BinaryPrimitives.WriteUInt32LittleEndian(
                output.AsSpan(i * 4),
                working[i] + baseState[i]);
        }
    }

    private static void QuarterRound(uint[] state, int a, int b, int c, int d)
    {
        state[a] += state[b];
        state[d] = RotateLeft(state[d] ^ state[a], 16);
        state[c] += state[d];
        state[b] = RotateLeft(state[b] ^ state[c], 12);
        state[a] += state[b];
        state[d] = RotateLeft(state[d] ^ state[a], 8);
        state[c] += state[d];
        state[b] = RotateLeft(state[b] ^ state[c], 7);
    }

    private static uint RotateLeft(uint value, int shift) =>
        (value << shift) | (value >> (32 - shift));
}
