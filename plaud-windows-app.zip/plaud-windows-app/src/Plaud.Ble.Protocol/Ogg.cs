using System.Buffers.Binary;

namespace Plaud.Ble.Protocol;

/// <summary>
/// Ogg-Opus container for raw Opus frames (20 ms mono) plus the CRC check the
/// device omits. Ported from the reference implementation.
/// </summary>
public static class Ogg
{
    private const uint Serial = 0x504C4144; // "PLAD"

    public static IReadOnlyList<byte[]> FramesFromRaw(byte[] data, int channels = 1)
    {
        var frameSize = 80 * Math.Max(1, channels);
        var frames = new List<byte[]>();
        for (var offset = 0; offset + frameSize <= data.Length; offset += frameSize)
        {
            frames.Add(data[offset..(offset + frameSize)]);
        }
        return frames;
    }

    public static byte[] WriteOggOpus(IReadOnlyList<byte[]> frames, int rate = 16000)
    {
        var head = new byte[19];
        "OpusHead"u8.CopyTo(head);
        head[8] = 1; // version
        head[9] = 1; // channels
        BinaryPrimitives.WriteUInt16LittleEndian(head.AsSpan(10), 312); // pre-skip
        BinaryPrimitives.WriteUInt32LittleEndian(head.AsSpan(12), (uint)rate);
        BinaryPrimitives.WriteInt16LittleEndian(head.AsSpan(16), 0);
        head[18] = 0;

        var vendor = "plud"u8.ToArray();
        var tags = new byte[8 + 4 + vendor.Length + 4];
        "OpusTags"u8.CopyTo(tags);
        BinaryPrimitives.WriteUInt32LittleEndian(tags.AsSpan(8), (uint)vendor.Length);
        vendor.CopyTo(tags, 12);
        BinaryPrimitives.WriteUInt32LittleEndian(tags.AsSpan(12 + vendor.Length), 0);

        var pages = new List<byte[]>
        {
            Page(0, 0, new[] { head }, 0x02),
            Page(1, 0, new[] { tags }, 0x00)
        };

        uint sequence = 2;
        long granule = 0;
        for (var index = 0; index < frames.Count; index += 50)
        {
            var chunk = frames.Skip(index).Take(50).ToList();
            granule += 960L * chunk.Count;
            var last = index + 50 >= frames.Count;
            pages.Add(Page(sequence, granule, chunk, last ? (byte)0x04 : (byte)0x00));
            sequence++;
        }

        var total = pages.Sum(page => page.Length);
        var output = new byte[total];
        var offset = 0;
        foreach (var page in pages)
        {
            page.CopyTo(output, offset);
            offset += page.Length;
        }
        return output;
    }

    public static bool VerifyOgg(byte[] data)
    {
        var offset = 0;
        var pages = 0;
        while (offset + 27 <= data.Length)
        {
            if (data[offset] != 0x4f || data[offset + 1] != 0x67 ||
                data[offset + 2] != 0x67 || data[offset + 3] != 0x53)
            {
                return false;
            }
            var segments = data[offset + 26];
            var headerEnd = offset + 27 + segments;
            if (headerEnd > data.Length)
            {
                return false;
            }
            var bodyLength = 0;
            for (var i = offset + 27; i < headerEnd; i++)
            {
                bodyLength += data[i];
            }
            var pageEnd = headerEnd + bodyLength;
            if (pageEnd > data.Length)
            {
                return false;
            }
            var expected = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset + 22));
            var page = data[offset..pageEnd];
            page[22] = 0;
            page[23] = 0;
            page[24] = 0;
            page[25] = 0;
            if (Crc32(page) != expected)
            {
                return false;
            }
            pages++;
            offset = pageEnd;
        }
        return pages > 0 && offset == data.Length;
    }

    private static byte[] Page(uint sequence, long granule, IReadOnlyList<byte[]> packets, byte headerType)
    {
        var lacing = new List<byte>();
        foreach (var packet in packets)
        {
            var remaining = packet.Length;
            while (remaining >= 255)
            {
                lacing.Add(255);
                remaining -= 255;
            }
            lacing.Add((byte)remaining);
        }

        var header = new byte[27 + lacing.Count];
        "OggS"u8.CopyTo(header);
        header[4] = 0;
        header[5] = headerType;
        BinaryPrimitives.WriteInt64LittleEndian(header.AsSpan(6), granule);
        BinaryPrimitives.WriteUInt32LittleEndian(header.AsSpan(14), Serial);
        BinaryPrimitives.WriteUInt32LittleEndian(header.AsSpan(18), sequence);
        BinaryPrimitives.WriteUInt32LittleEndian(header.AsSpan(22), 0);
        header[26] = (byte)lacing.Count;
        for (var i = 0; i < lacing.Count; i++)
        {
            header[27 + i] = lacing[i];
        }

        var bodyLength = packets.Sum(packet => packet.Length);
        var output = new byte[header.Length + bodyLength];
        header.CopyTo(output, 0);
        var offset = header.Length;
        foreach (var packet in packets)
        {
            packet.CopyTo(output, offset);
            offset += packet.Length;
        }

        BinaryPrimitives.WriteUInt32LittleEndian(output.AsSpan(22), Crc32(output));
        return output;
    }

    private static uint Crc32(ReadOnlySpan<byte> data)
    {
        uint crc = 0;
        foreach (var value in data)
        {
            crc ^= (uint)value << 24;
            for (var bit = 0; bit < 8; bit++)
            {
                crc = (crc & 0x80000000) != 0
                    ? (crc << 1) ^ 0x04c11db7
                    : crc << 1;
            }
        }
        return crc;
    }
}
