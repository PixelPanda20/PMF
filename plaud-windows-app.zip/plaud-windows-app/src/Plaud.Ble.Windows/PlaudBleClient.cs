using System.Text;
using System.Threading.Channels;
using Plaud.Ble.Protocol;
using PlaudOnboarding;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.Advertisement;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Security.Cryptography;
using Windows.Storage.Streams;

namespace Plaud.Ble.Windows;

public sealed record PlaudDeviceInfo(
    ulong Address,
    string Name,
    string Serial,
    short Rssi,
    string AddressText);

public sealed record PlaudSession(uint SessionId, uint Size, DateTimeOffset RecordedAt);

public sealed record PlaudDeviceHandshake(int PortVersion, int Channels, bool OggAudio);

/// <summary>
/// Windows BLE transport for protocol 20. Framing, crypto and Ogg handling live
/// in the tested Plaud.Ble.Protocol library; this class only moves bytes over
/// Windows.Devices.Bluetooth.
/// </summary>
public sealed class PlaudBleClient : IAsyncDisposable
{
    private const int ChunkSize = 100;

    private readonly Channel<byte[]> _inbox = Channel.CreateBounded<byte[]>(
        new BoundedChannelOptions(512) { SingleReader = true, SingleWriter = true });

    private BluetoothLEDevice? _device;
    private GattCharacteristic? _notify;
    private GattCharacteristic? _write;
    private SessionCipher? _cipher;
    private PlaudAccount? _account;
    private string _serial = string.Empty;

    public PlaudDeviceHandshake? Handshake { get; private set; }
    public bool IsConnected => _device?.ConnectionStatus == BluetoothConnectionStatus.Connected;

    public async Task<IReadOnlyList<PlaudDeviceInfo>> ScanAsync(
        TimeSpan timeout,
        CancellationToken cancellationToken = default)
    {
        var found = new Dictionary<ulong, PlaudDeviceInfo>();
        var watcher = new BluetoothLEAdvertisementWatcher
        {
            ScanningMode = BluetoothLEScanningMode.Active
        };

        watcher.Received += (_, args) =>
        {
            var advertisement = args.Advertisement;
            var manufacturer = ReadManufacturerData(advertisement, out var serial);
            var isPlaud =
                advertisement.LocalName.Contains("plaud", StringComparison.OrdinalIgnoreCase)
                || advertisement.ServiceUuids.Contains(new Guid(PlaudProtocol.ServiceUuid))
                || manufacturer;
            if (!isPlaud)
            {
                return;
            }

            var name = string.IsNullOrWhiteSpace(advertisement.LocalName)
                ? "Plaud"
                : advertisement.LocalName;
            found[args.BluetoothAddress] = new PlaudDeviceInfo(
                args.BluetoothAddress,
                name,
                serial,
                args.RawSignalStrengthInDBm,
                FormatAddress(args.BluetoothAddress));
        };

        watcher.Start();
        try
        {
            await Task.Delay(timeout, cancellationToken).ConfigureAwait(false);
        }
        finally
        {
            watcher.Stop();
        }
        return found.Values.OrderByDescending(device => device.Rssi).ToList();
    }

    public async Task ConnectAsync(
        PlaudDeviceInfo device,
        PlaudAccount account,
        CancellationToken cancellationToken = default)
    {
        _account = account;
        _serial = string.IsNullOrWhiteSpace(device.Serial) ? account.BindToken : device.Serial;

        _device = await BluetoothLEDevice.FromBluetoothAddressAsync(device.Address)
            .AsTask(cancellationToken)
            .ConfigureAwait(false)
            ?? throw new InvalidOperationException("Gerät konnte nicht geöffnet werden.");

        var services = await _device
            .GetGattServicesForUuidAsync(new Guid(PlaudProtocol.ServiceUuid), BluetoothCacheMode.Uncached)
            .AsTask(cancellationToken)
            .ConfigureAwait(false);
        var service = services.Services.FirstOrDefault()
            ?? throw new InvalidOperationException("Plaud-Dienst wurde nicht gefunden.");

        var notifyResult = await service
            .GetCharacteristicsForUuidAsync(new Guid(PlaudProtocol.NotifyUuid), BluetoothCacheMode.Uncached)
            .AsTask(cancellationToken)
            .ConfigureAwait(false);
        _notify = notifyResult.Characteristics.FirstOrDefault()
            ?? throw new InvalidOperationException("Notify-Charakteristik fehlt.");

        var writeResult = await service
            .GetCharacteristicsForUuidAsync(new Guid(PlaudProtocol.WriteUuid), BluetoothCacheMode.Uncached)
            .AsTask(cancellationToken)
            .ConfigureAwait(false);
        _write = writeResult.Characteristics.FirstOrDefault()
            ?? throw new InvalidOperationException("Write-Charakteristik fehlt.");

        _notify.ValueChanged += OnValueChanged;
        var status = await _notify
            .WriteClientCharacteristicConfigurationDescriptorAsync(
                GattClientCharacteristicConfigurationDescriptorValue.Notify)
            .AsTask(cancellationToken)
            .ConfigureAwait(false);
        if (status != GattCommunicationStatus.Success)
        {
            throw new InvalidOperationException($"Notifications konnten nicht aktiviert werden ({status}).");
        }

        await UnlockAsync(cancellationToken).ConfigureAwait(false);
        await HandshakeAsync(cancellationToken).ConfigureAwait(false);
    }

    public async Task<IReadOnlyList<PlaudSession>> ListSessionsAsync(
        CancellationToken cancellationToken = default)
    {
        await SendAsync(
                PlaudProtocol.SessionListRequest((uint)DateTimeOffset.UtcNow.ToUnixTimeSeconds()))
            .ConfigureAwait(false);

        var sessions = new Dictionary<uint, PlaudSession>();
        var total = -1;
        var deadline = DateTimeOffset.UtcNow.AddSeconds(60);
        while (DateTimeOffset.UtcNow < deadline && (total < 0 || sessions.Count < total))
        {
            var packet = await ReceiveAsync(TimeSpan.FromSeconds(15), cancellationToken)
                .ConfigureAwait(false);
            if (packet.Length < 11 || packet[0] != 1 ||
                PlaudProtocol.ReadU16(packet, 1) != PlaudProtocol.CmdGetRecSessions)
            {
                continue;
            }
            var list = PlaudProtocol.ParseSessionList(packet, Handshake?.PortVersion ?? 20);
            total = list.Total;
            foreach (var entry in list.Entries)
            {
                sessions[entry.SessionId] = new PlaudSession(
                    entry.SessionId,
                    entry.Size,
                    DateTimeOffset.FromUnixTimeSeconds(entry.SessionId));
            }
            if (list.Entries.Count == 0)
            {
                break;
            }
        }
        return sessions.Values.OrderByDescending(session => session.SessionId).ToList();
    }

    public async Task<byte[]> DownloadAsync(
        PlaudSession session,
        IProgress<uint>? progress = null,
        CancellationToken cancellationToken = default)
    {
        var assembler = new TransferAssembler();
        for (var attempt = 0; attempt < 3; attempt++)
        {
            try
            {
                var data = await PullOnceAsync(session, assembler, progress, cancellationToken)
                    .ConfigureAwait(false);
                if (session.Size > 0 && data.Length < session.Size)
                {
                    throw new InvalidOperationException(
                        $"Transfer unvollständig ({data.Length}/{session.Size} Bytes).");
                }
                return ToPlayableAudio(data);
            }
            catch (TransferGapException)
            {
                // resume from the missing offset
            }
        }
        throw new InvalidOperationException("Transfer nach mehreren Versuchen abgebrochen.");
    }

    private async Task<byte[]> PullOnceAsync(
        PlaudSession session,
        TransferAssembler assembler,
        IProgress<uint>? progress,
        CancellationToken cancellationToken)
    {
        await SendAsync(
                PlaudProtocol.SyncStart(
                    session.SessionId,
                    assembler.Expected,
                    session.Size == 0 ? PlaudProtocol.EndOfData : session.Size))
            .ConfigureAwait(false);

        var head = await ReceiveMatchingAsync(
                packet => packet.Length >= 3 && packet[0] == 1 &&
                          PlaudProtocol.ReadU16(packet, 1) == PlaudProtocol.CmdSyncFileStart,
                TimeSpan.FromSeconds(15),
                cancellationToken)
            .ConfigureAwait(false)
            ?? throw new InvalidOperationException("Gerät hat den Transfer nicht bestätigt.");
        if (head.Length > 7 && head[7] > 0)
        {
            throw new InvalidOperationException($"Gerät verweigert den Transfer (Status {head[7]}).");
        }

        var version = Handshake?.PortVersion ?? 20;
        while (true)
        {
            var packet = await ReceiveAsync(TimeSpan.FromSeconds(25), cancellationToken)
                .ConfigureAwait(false);
            if (packet.Length >= 3 && packet[0] == 1 &&
                PlaudProtocol.ReadU16(packet, 1) == PlaudProtocol.CmdSyncFileTail)
            {
                break;
            }
            if (packet.Length > 9 && packet[0] == 2 && PlaudProtocol.ReadU32(packet, 1) == PlaudProtocol.EndOfData)
            {
                break;
            }
            var parsed = PlaudProtocol.ParseDataPacket(packet, version, session.SessionId);
            if (parsed is null)
            {
                continue;
            }
            assembler.Add(parsed.Offset, parsed.Chunk);
            progress?.Report(assembler.Expected);
        }
        return assembler.ToArray();
    }

    private byte[] ToPlayableAudio(byte[] data)
    {
        var account = _account ?? throw new InvalidOperationException("Keine Identität geladen.");
        byte[] audio;
        if (data.Length >= 8 && Encoding.ASCII.GetString(data, 0, 8) == "PLAUD.AI")
        {
            audio = IdentityUnlock.DecryptPlaudFile(account.PrivateKeyPem, data);
        }
        else if (Handshake?.OggAudio == true)
        {
            audio = data;
        }
        else if ((Handshake?.Channels ?? 1) == 1)
        {
            audio = Ogg.WriteOggOpus(Ogg.FramesFromRaw(data, 1));
        }
        else
        {
            throw new InvalidOperationException("Mehrkanal-Rohaudio wird nicht unterstützt.");
        }

        if (!Ogg.VerifyOgg(audio))
        {
            throw new InvalidOperationException("Ogg-Prüfsummen stimmen nicht – Transfer beschädigt.");
        }
        return audio;
    }

    private async Task UnlockAsync(CancellationToken cancellationToken)
    {
        var account = _account ?? throw new InvalidOperationException("Keine Identität geladen.");
        var signature = account.SnSignature.TryGetValue(_serial, out var exact)
            ? exact
            : account.SnSignature.TryGetValue("*", out var wildcard)
                ? wildcard
                : account.SnSignature.Values.FirstOrDefault()
                  ?? throw new InvalidOperationException("Keine SN-Signatur für dieses Gerät.");

        var signatureBytes = Convert.FromBase64String(signature);
        var parts = new Dictionary<int, byte[]>();
        var total = 0;
        var wantsPublicKey = false;

        void Take(byte[]? packet)
        {
            if (packet is null || packet.Length < 4)
            {
                return;
            }
            var id = PlaudProtocol.ReadU16(packet, 0);
            if (id == PlaudProtocol.FePubkeyRequest)
            {
                wantsPublicKey = true;
            }
            if (id != PlaudProtocol.FePubkey)
            {
                return;
            }
            total = packet[2];
            parts[packet[3]] = packet[4..];
        }

        async Task SendChunksAsync(int command, byte[] blob)
        {
            var count = (blob.Length + ChunkSize - 1) / ChunkSize;
            for (var index = 0; index < count; index++)
            {
                var chunk = blob.Skip(index * ChunkSize).Take(ChunkSize).ToArray();
                var packet = new byte[4 + chunk.Length];
                PlaudProtocol.U16(command).CopyTo(packet, 0);
                packet[2] = (byte)count;
                packet[3] = (byte)index;
                chunk.CopyTo(packet, 4);
                await SendAsync(packet).ConfigureAwait(false);
                Take(await ReceiveFeAsync(TimeSpan.FromSeconds(2.5), cancellationToken)
                    .ConfigureAwait(false));
            }
        }

        await SendChunksAsync(PlaudProtocol.FeSignature, signatureBytes).ConfigureAwait(false);

        var deadline = DateTimeOffset.UtcNow.AddSeconds(8);
        while (total == 0 && DateTimeOffset.UtcNow < deadline)
        {
            Take(await ReceiveFeAsync(TimeSpan.FromSeconds(2), cancellationToken).ConfigureAwait(false));
        }
        if (wantsPublicKey && !string.IsNullOrWhiteSpace(account.PublicKeyPem))
        {
            await SendChunksAsync(
                    PlaudProtocol.FePubkey,
                    Encoding.ASCII.GetBytes(account.PublicKeyPem))
                .ConfigureAwait(false);
        }
        if (total == 0)
        {
            throw new InvalidOperationException("Gerät hat die SN-Signatur nicht bestätigt.");
        }

        var collectDeadline = DateTimeOffset.UtcNow.AddSeconds(10);
        while (parts.Count < total && DateTimeOffset.UtcNow < collectDeadline)
        {
            Take(await ReceiveFeAsync(TimeSpan.FromSeconds(2), cancellationToken).ConfigureAwait(false));
        }
        if (parts.Count < total)
        {
            throw new InvalidOperationException($"Session-Secret unvollständig ({parts.Count}/{total}).");
        }

        var secret = new byte[parts.Values.Sum(part => part.Length)];
        var offset = 0;
        for (var index = 0; index < total; index++)
        {
            var part = parts[index]
                ?? throw new InvalidOperationException($"Session-Secret-Teil {index} fehlt.");
            part.CopyTo(secret, offset);
            offset += part.Length;
        }

        var keys = IdentityUnlock.DecryptSessionSecret(account.PrivateKeyPem, secret);
        _cipher = new SessionCipher(keys.Key, keys.Nonce, keys.AssociatedData);
    }

    private async Task HandshakeAsync(CancellationToken cancellationToken)
    {
        var account = _account ?? throw new InvalidOperationException("Keine Identität geladen.");
        await SendAsync(PlaudProtocol.HandshakePacket(account.BindToken, 20)).ConfigureAwait(false);

        var response = await ReceiveMatchingAsync(
                packet => packet.Length >= 3 && packet[0] == 1 &&
                          (PlaudProtocol.ReadU16(packet, 1) == PlaudProtocol.CmdHandshake ||
                           PlaudProtocol.ReadU16(packet, 1) == PlaudProtocol.CmdGetSsn),
                TimeSpan.FromSeconds(15),
                cancellationToken)
            .ConfigureAwait(false)
            ?? throw new InvalidOperationException("Keine Handshake-Antwort vom Gerät.");

        if (PlaudProtocol.ReadU16(response, 1) == PlaudProtocol.CmdGetSsn)
        {
            await SendAsync(PlaudProtocol.HandshakePacket(account.BindToken, 20, second: true))
                .ConfigureAwait(false);
            response = await ReceiveMatchingAsync(
                    packet => packet.Length >= 3 && packet[0] == 1 &&
                              PlaudProtocol.ReadU16(packet, 1) == PlaudProtocol.CmdHandshake,
                    TimeSpan.FromSeconds(15),
                    cancellationToken)
                .ConfigureAwait(false)
                ?? throw new InvalidOperationException("Keine Handshake-Antwort vom Gerät.");
        }

        var parsed = PlaudProtocol.ParseHandshake(response);
        if (parsed.Status != 0)
        {
            throw new InvalidOperationException($"Handshake abgelehnt (Status {parsed.Status}).");
        }
        Handshake = new PlaudDeviceHandshake(parsed.PortVersion, parsed.Channels, parsed.OggAudio);
    }

    private async Task SendAsync(byte[] packet)
    {
        var write = _write ?? throw new InvalidOperationException("Nicht verbunden.");
        var payload = _cipher is null ? packet : _cipher.Encrypt(packet);
        var buffer = CryptographicBuffer.CreateFromByteArray(payload);
        var result = await write
            .WriteValueWithResultAsync(buffer, GattWriteOption.WriteWithoutResponse)
            .AsTask()
            .ConfigureAwait(false);
        if (result.Status != GattCommunicationStatus.Success)
        {
            throw new InvalidOperationException($"Schreiben fehlgeschlagen ({result.Status}).");
        }
    }

    private async Task<byte[]> ReceiveAsync(TimeSpan timeout, CancellationToken cancellationToken)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(timeout);
        try
        {
            return await _inbox.Reader.ReadAsync(cts.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException("Zeitüberschreitung beim Gerät.");
        }
    }

    private async Task<byte[]?> ReceiveFeAsync(TimeSpan timeout, CancellationToken cancellationToken)
    {
        try
        {
            var packet = await ReceiveAsync(timeout, cancellationToken).ConfigureAwait(false);
            if (packet.Length >= 2)
            {
                var id = PlaudProtocol.ReadU16(packet, 0);
                if (id is PlaudProtocol.FePubkey or PlaudProtocol.FePubkeyRequest)
                {
                    return packet;
                }
            }
            return null;
        }
        catch (TimeoutException)
        {
            return null;
        }
    }

    private async Task<byte[]?> ReceiveMatchingAsync(
        Func<byte[], bool> match,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var deadline = DateTimeOffset.UtcNow + timeout;
        while (DateTimeOffset.UtcNow < deadline)
        {
            var remaining = deadline - DateTimeOffset.UtcNow;
            if (remaining <= TimeSpan.Zero)
            {
                break;
            }
            byte[] packet;
            try
            {
                packet = await ReceiveAsync(remaining, cancellationToken).ConfigureAwait(false);
            }
            catch (TimeoutException)
            {
                return null;
            }
            if (packet.Length >= 2 && PlaudProtocol.ReadU16(packet, 0) == PlaudProtocol.EccFe30)
            {
                throw new InvalidOperationException(
                    "Gerät verwendet Protokoll 30 (ECC). Dieser Firmware-Stand wird nicht unterstützt.");
            }
            if (match(packet))
            {
                return packet;
            }
        }
        return null;
    }

    private void OnValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
    {
        var reader = DataReader.FromBuffer(args.CharacteristicValue);
        var bytes = new byte[reader.UnconsumedBufferLength];
        reader.ReadBytes(bytes);

        if (_cipher is not null)
        {
            try
            {
                bytes = _cipher.Decrypt(bytes);
            }
            catch (ProtocolException)
            {
                return; // foreign/corrupt packet
            }
        }
        _inbox.Writer.TryWrite(bytes);
    }

    private static bool ReadManufacturerData(
        BluetoothLEAdvertisement advertisement,
        out string serial)
    {
        serial = string.Empty;
        foreach (var section in advertisement.DataSections)
        {
            if (section.DataType != 0xFF)
            {
                continue;
            }
            var reader = DataReader.FromBuffer(section.Data);
            var bytes = new byte[reader.UnconsumedBufferLength];
            reader.ReadBytes(bytes);
            if (bytes.Length < 2)
            {
                continue;
            }
            var company = (ushort)(bytes[0] | (bytes[1] << 8));
            if (company != 0x005d)
            {
                continue;
            }
            // Serial lives at raw[9..17] of the manufacturer payload (after the
            // 2-byte company id) on the Note Pro.
            if (bytes.Length >= 19)
            {
                var candidate = bytes[11..19];
                serial = candidate.All(value => value is >= 32 and < 127)
                    ? Encoding.ASCII.GetString(candidate)
                    : Convert.ToHexString(candidate);
            }
            return true;
        }
        return false;
    }

    private static string FormatAddress(ulong address)
    {
        var bytes = BitConverter.GetBytes(address).Take(6).Reverse();
        return string.Join(":", bytes.Select(value => value.ToString("X2")));
    }

    public void Disconnect()
    {
        try
        {
            _notify?.WriteClientCharacteristicConfigurationDescriptorAsync(
                GattClientCharacteristicConfigurationDescriptorValue.None);
        }
        catch
        {
            // already gone
        }
        if (_notify is not null)
        {
            _notify.ValueChanged -= OnValueChanged;
        }
        _device?.Dispose();
        _device = null;
        _notify = null;
        _write = null;
        _cipher = null;
        Handshake = null;
    }

    public ValueTask DisposeAsync()
    {
        Disconnect();
        return ValueTask.CompletedTask;
    }
}
