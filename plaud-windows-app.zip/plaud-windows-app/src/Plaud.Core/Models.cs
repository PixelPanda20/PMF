namespace Plaud.Core;

public enum RecordingStatus
{
    Imported,
    Transcribing,
    Transcribed,
    Summarizing,
    Ready,
    Error
}

public sealed class Recording
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "Aufnahme";
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public double? DurationSeconds { get; set; }
    public string AudioPath { get; set; } = string.Empty;
    public string? Transcript { get; set; }
    public string? TranscriptLanguage { get; set; }
    public string? SummaryJson { get; set; }
    public RecordingStatus Status { get; set; } = RecordingStatus.Imported;
    public string? Error { get; set; }
    public string TemplateId { get; set; } = "standard";
    public string? DeviceSessionId { get; set; }
    public IReadOnlyList<string> Tags { get; set; } = Array.Empty<string>();

    public bool HasTranscript => !string.IsNullOrWhiteSpace(Transcript);
    public bool HasSummary => !string.IsNullOrWhiteSpace(SummaryJson);
}

public sealed record TranscriptSegment(double Start, double End, string Text);

public sealed record TranscriptResult(
    string Text,
    string? Language,
    double? Duration,
    IReadOnlyList<TranscriptSegment> Segments);

public interface ITranscriber
{
    Task<TranscriptResult> TranscribeAsync(
        Stream audio,
        string fileName,
        string? language,
        CancellationToken cancellationToken = default);
}

public interface ISummarizer
{
    Task<string> SummarizeAsync(
        string transcript,
        string templateId,
        CancellationToken cancellationToken = default);

    Task<string> AskAsync(
        string question,
        string transcript,
        string? summaryJson,
        CancellationToken cancellationToken = default);
}
