namespace Plaud.Core;

/// <summary>Local, per-user locations. Nothing is written outside %LOCALAPPDATA%.</summary>
public static class AppPaths
{
    public static string Root =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "PlaudRecorder");

    public static string Database => Path.Combine(Root, "plaud.db");
    public static string Audio => Path.Combine(Root, "audio");
    public static string Identity => Path.Combine(Root, "identity.json");
    public static string Logs => Path.Combine(Root, "logs");
}

public sealed class AudioStore
{
    private readonly string _root;

    public AudioStore(string rootDirectory)
    {
        _root = rootDirectory;
    }

    /// <summary>Stores the audio under a generated id and returns the absolute path.</summary>
    public async Task<string> SaveAsync(
        Stream content,
        string extension = ".ogg",
        CancellationToken cancellationToken = default)
    {
        Directory.CreateDirectory(_root);
        var safeExtension = extension.StartsWith('.') ? extension : "." + extension;
        var path = Path.Combine(_root, Guid.NewGuid().ToString("N") + safeExtension);

        await using var file = new FileStream(
            path,
            FileMode.CreateNew,
            FileAccess.Write,
            FileShare.None,
            bufferSize: 81920,
            useAsync: true);
        await content.CopyToAsync(file, cancellationToken).ConfigureAwait(false);
        return path;
    }

    public void Delete(string path)
    {
        if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
        {
            File.Delete(path);
        }
    }
}
