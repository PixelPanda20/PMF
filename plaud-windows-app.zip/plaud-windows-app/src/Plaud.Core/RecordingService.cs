namespace Plaud.Core;

/// <summary>
/// Import pipeline: audio → local file + library row → transcript → summary.
/// Each step persists its state so a crash never loses a recording.
/// </summary>
public sealed class RecordingService
{
    private readonly PlaudStore _store;
    private readonly AudioStore _audio;
    private readonly ITranscriber _transcriber;
    private readonly ISummarizer _summarizer;

    public RecordingService(
        PlaudStore store,
        AudioStore audio,
        ITranscriber transcriber,
        ISummarizer summarizer)
    {
        _store = store;
        _audio = audio;
        _transcriber = transcriber;
        _summarizer = summarizer;
    }

    public async Task<Recording> ImportAsync(
        Stream audio,
        string title,
        string extension = ".ogg",
        string? deviceSessionId = null,
        CancellationToken cancellationToken = default)
    {
        var path = await _audio.SaveAsync(audio, extension, cancellationToken).ConfigureAwait(false);
        var recording = new Recording
        {
            Title = string.IsNullOrWhiteSpace(title) ? "Aufnahme" : title.Trim(),
            AudioPath = path,
            DeviceSessionId = deviceSessionId
        };
        _store.Insert(recording);
        return recording;
    }

    public async Task<Recording> TranscribeAsync(
        string recordingId,
        string? language = null,
        CancellationToken cancellationToken = default)
    {
        var recording = Require(recordingId);
        recording.Status = RecordingStatus.Transcribing;
        recording.Error = null;
        _store.Update(recording);

        try
        {
            await using var audio = File.OpenRead(recording.AudioPath);
            var result = await _transcriber
                .TranscribeAsync(audio, Path.GetFileName(recording.AudioPath), language, cancellationToken)
                .ConfigureAwait(false);

            recording.Transcript = result.Text;
            recording.TranscriptLanguage = result.Language;
            recording.DurationSeconds = result.Duration;
            recording.Status = RecordingStatus.Transcribed;
            _store.Update(recording);
            return recording;
        }
        catch (Exception error) when (error is not OperationCanceledException)
        {
            recording.Status = RecordingStatus.Error;
            recording.Error = error.Message;
            _store.Update(recording);
            throw;
        }
    }

    public async Task<Recording> SummarizeAsync(
        string recordingId,
        string templateId = "standard",
        CancellationToken cancellationToken = default)
    {
        var recording = Require(recordingId);
        if (!recording.HasTranscript)
        {
            throw new InvalidOperationException("Die Aufnahme hat noch kein Transkript.");
        }

        recording.Status = RecordingStatus.Summarizing;
        recording.Error = null;
        _store.Update(recording);

        try
        {
            recording.SummaryJson = await _summarizer
                .SummarizeAsync(recording.Transcript!, templateId, cancellationToken)
                .ConfigureAwait(false);
            recording.TemplateId = templateId;
            recording.Status = RecordingStatus.Ready;
            _store.Update(recording);
            return recording;
        }
        catch (Exception error) when (error is not OperationCanceledException)
        {
            recording.Status = RecordingStatus.Error;
            recording.Error = error.Message;
            _store.Update(recording);
            throw;
        }
    }

    public async Task<string> AskAsync(
        string recordingId,
        string question,
        CancellationToken cancellationToken = default)
    {
        var recording = Require(recordingId);
        if (!recording.HasTranscript)
        {
            throw new InvalidOperationException("Die Aufnahme hat noch kein Transkript.");
        }
        return await _summarizer
            .AskAsync(question, recording.Transcript!, recording.SummaryJson, cancellationToken)
            .ConfigureAwait(false);
    }

    public void Delete(string recordingId)
    {
        var recording = _store.Get(recordingId);
        if (recording is null)
        {
            return;
        }
        _store.Delete(recordingId);
        _audio.Delete(recording.AudioPath);
    }

    private Recording Require(string recordingId) =>
        _store.Get(recordingId)
        ?? throw new KeyNotFoundException($"Aufnahme {recordingId} wurde nicht gefunden.");
}
