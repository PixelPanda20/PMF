using Microsoft.Data.Sqlite;

namespace Plaud.Core;

/// <summary>
/// SQLite-backed library. One connection per operation keeps it safe for the
/// UI thread and background jobs without a global lock.
/// </summary>
public sealed class PlaudStore
{
    private readonly string _connectionString;

    public PlaudStore(string databasePath)
    {
        var directory = Path.GetDirectoryName(Path.GetFullPath(databasePath));
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = databasePath,
            Mode = SqliteOpenMode.ReadWriteCreate
        }.ToString();
    }

    public void Initialize()
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText =
            """
            PRAGMA journal_mode = WAL;
            CREATE TABLE IF NOT EXISTS recordings (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                created_at TEXT NOT NULL,
                duration REAL NULL,
                audio_path TEXT NOT NULL,
                transcript TEXT NULL,
                transcript_language TEXT NULL,
                summary_json TEXT NULL,
                status INTEGER NOT NULL,
                error TEXT NULL,
                template_id TEXT NOT NULL DEFAULT 'standard',
                device_session_id TEXT NULL
            );
            CREATE TABLE IF NOT EXISTS recording_tags (
                recording_id TEXT NOT NULL,
                tag TEXT NOT NULL,
                PRIMARY KEY (recording_id, tag)
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_recordings_created ON recordings(created_at DESC);
            """;
        command.ExecuteNonQuery();
    }

    public Recording Insert(Recording recording)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText =
            """
            INSERT INTO recordings
                (id, title, created_at, duration, audio_path, transcript,
                 transcript_language, summary_json, status, error, template_id, device_session_id)
            VALUES
                ($id, $title, $created, $duration, $audio, $transcript,
                 $language, $summary, $status, $error, $template, $session);
            """;
        Bind(command, recording);
        command.ExecuteNonQuery();
        return recording;
    }

    public void Update(Recording recording)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText =
            """
            UPDATE recordings SET
                title = $title,
                duration = $duration,
                audio_path = $audio,
                transcript = $transcript,
                transcript_language = $language,
                summary_json = $summary,
                status = $status,
                error = $error,
                template_id = $template,
                device_session_id = $session
            WHERE id = $id;
            """;
        Bind(command, recording);
        command.ExecuteNonQuery();
    }

    public Recording? Get(string id)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT * FROM recordings WHERE id = $id LIMIT 1;";
        command.Parameters.AddWithValue("$id", id);
        using var reader = command.ExecuteReader();
        if (!reader.Read())
        {
            return null;
        }
        var recording = Read(reader);
        recording.Tags = LoadTags(connection, id);
        return recording;
    }

    public IReadOnlyList<Recording> List(string? search = null, string? tag = null, int limit = 200)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        var conditions = new List<string>();
        if (!string.IsNullOrWhiteSpace(search))
        {
            conditions.Add(
                "(title LIKE $search OR transcript LIKE $search OR summary_json LIKE $search)");
            command.Parameters.AddWithValue("$search", $"%{search.Trim()}%");
        }
        if (!string.IsNullOrWhiteSpace(tag))
        {
            conditions.Add(
                "id IN (SELECT recording_id FROM recording_tags WHERE tag = $tag)");
            command.Parameters.AddWithValue("$tag", tag.Trim());
        }
        var where = conditions.Count > 0 ? "WHERE " + string.Join(" AND ", conditions) : string.Empty;
        command.CommandText =
            $"SELECT * FROM recordings {where} ORDER BY created_at DESC LIMIT $limit;";
        command.Parameters.AddWithValue("$limit", Math.Clamp(limit, 1, 1000));

        var results = new List<Recording>();
        using (var reader = command.ExecuteReader())
        {
            while (reader.Read())
            {
                results.Add(Read(reader));
            }
        }
        foreach (var recording in results)
        {
            recording.Tags = LoadTags(connection, recording.Id);
        }
        return results;
    }

    public void SetTags(string recordingId, IEnumerable<string> tags)
    {
        using var connection = Open();
        using var transaction = connection.BeginTransaction();

        using (var delete = connection.CreateCommand())
        {
            delete.Transaction = transaction;
            delete.CommandText = "DELETE FROM recording_tags WHERE recording_id = $id;";
            delete.Parameters.AddWithValue("$id", recordingId);
            delete.ExecuteNonQuery();
        }

        foreach (var tag in tags
                     .Select(value => value.Trim())
                     .Where(value => value.Length > 0)
                     .Distinct(StringComparer.OrdinalIgnoreCase))
        {
            using var insert = connection.CreateCommand();
            insert.Transaction = transaction;
            insert.CommandText =
                "INSERT OR IGNORE INTO recording_tags (recording_id, tag) VALUES ($id, $tag);";
            insert.Parameters.AddWithValue("$id", recordingId);
            insert.Parameters.AddWithValue("$tag", tag);
            insert.ExecuteNonQuery();
        }

        transaction.Commit();
    }

    public IReadOnlyList<string> ListTags()
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT DISTINCT tag FROM recording_tags ORDER BY tag;";
        var tags = new List<string>();
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            tags.Add(reader.GetString(0));
        }
        return tags;
    }

    public void Delete(string id)
    {
        using var connection = Open();
        using var transaction = connection.BeginTransaction();
        foreach (var sql in new[]
                 {
                     "DELETE FROM recording_tags WHERE recording_id = $id;",
                     "DELETE FROM recordings WHERE id = $id;"
                 })
        {
            using var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandText = sql;
            command.Parameters.AddWithValue("$id", id);
            command.ExecuteNonQuery();
        }
        transaction.Commit();
    }

    public string? GetSetting(string key)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT value FROM settings WHERE key = $key LIMIT 1;";
        command.Parameters.AddWithValue("$key", key);
        return command.ExecuteScalar() as string;
    }

    public void SetSetting(string key, string value)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText =
            """
            INSERT INTO settings (key, value) VALUES ($key, $value)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value;
            """;
        command.Parameters.AddWithValue("$key", key);
        command.Parameters.AddWithValue("$value", value);
        command.ExecuteNonQuery();
    }

    private SqliteConnection Open()
    {
        var connection = new SqliteConnection(_connectionString);
        connection.Open();
        return connection;
    }

    private static void Bind(SqliteCommand command, Recording recording)
    {
        command.Parameters.AddWithValue("$id", recording.Id);
        command.Parameters.AddWithValue("$title", recording.Title);
        command.Parameters.AddWithValue("$created", recording.CreatedAt.ToString("O"));
        command.Parameters.AddWithValue(
            "$duration",
            recording.DurationSeconds is { } duration ? duration : DBNull.Value);
        command.Parameters.AddWithValue("$audio", recording.AudioPath);
        command.Parameters.AddWithValue(
            "$transcript",
            (object?)recording.Transcript ?? DBNull.Value);
        command.Parameters.AddWithValue(
            "$language",
            (object?)recording.TranscriptLanguage ?? DBNull.Value);
        command.Parameters.AddWithValue(
            "$summary",
            (object?)recording.SummaryJson ?? DBNull.Value);
        command.Parameters.AddWithValue("$status", (int)recording.Status);
        command.Parameters.AddWithValue("$error", (object?)recording.Error ?? DBNull.Value);
        command.Parameters.AddWithValue("$template", recording.TemplateId);
        command.Parameters.AddWithValue(
            "$session",
            (object?)recording.DeviceSessionId ?? DBNull.Value);
    }

    private static Recording Read(SqliteDataReader reader) =>
        new()
        {
            Id = reader.GetString(reader.GetOrdinal("id")),
            Title = reader.GetString(reader.GetOrdinal("title")),
            CreatedAt = DateTimeOffset.Parse(reader.GetString(reader.GetOrdinal("created_at"))),
            DurationSeconds = reader.IsDBNull(reader.GetOrdinal("duration"))
                ? null
                : reader.GetDouble(reader.GetOrdinal("duration")),
            AudioPath = reader.GetString(reader.GetOrdinal("audio_path")),
            Transcript = reader.IsDBNull(reader.GetOrdinal("transcript"))
                ? null
                : reader.GetString(reader.GetOrdinal("transcript")),
            TranscriptLanguage = reader.IsDBNull(reader.GetOrdinal("transcript_language"))
                ? null
                : reader.GetString(reader.GetOrdinal("transcript_language")),
            SummaryJson = reader.IsDBNull(reader.GetOrdinal("summary_json"))
                ? null
                : reader.GetString(reader.GetOrdinal("summary_json")),
            Status = (RecordingStatus)reader.GetInt32(reader.GetOrdinal("status")),
            Error = reader.IsDBNull(reader.GetOrdinal("error"))
                ? null
                : reader.GetString(reader.GetOrdinal("error")),
            TemplateId = reader.GetString(reader.GetOrdinal("template_id")),
            DeviceSessionId = reader.IsDBNull(reader.GetOrdinal("device_session_id"))
                ? null
                : reader.GetString(reader.GetOrdinal("device_session_id"))
        };

    private static IReadOnlyList<string> LoadTags(SqliteConnection connection, string id)
    {
        using var command = connection.CreateCommand();
        command.CommandText =
            "SELECT tag FROM recording_tags WHERE recording_id = $id ORDER BY tag;";
        command.Parameters.AddWithValue("$id", id);
        var tags = new List<string>();
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            tags.Add(reader.GetString(0));
        }
        return tags;
    }
}
