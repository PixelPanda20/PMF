using PlaudOnboarding;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace PlaudOnboarding.ViewModels;

/// <summary>
/// Framework-neutral view model for the onboarding form (WinUI 3, WPF, MAUI).
/// The token is only held in memory and cleared after a successful exchange.
/// </summary>
public sealed class OnboardingViewModel : INotifyPropertyChanged
{
    private readonly PlaudOnboardingClient _client;

    private string _userToken = string.Empty;
    private string _serial = string.Empty;
    private string _bindToken = string.Empty;
    private string _identityPath;
    private bool _isBusy;
    private string? _errorMessage;
    private string? _successMessage;
    private IReadOnlyList<string> _serials = Array.Empty<string>();

    public OnboardingViewModel(PlaudOnboardingClient? client = null, string? identityPath = null)
    {
        _client = client ?? new PlaudOnboardingClient();
        _identityPath = identityPath ?? DefaultIdentityPath();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    /// <summary>%LOCALAPPDATA%\PlaudOnboarding\identity.json</summary>
    public static string DefaultIdentityPath() =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "PlaudOnboarding",
            "identity.json");

    public string Serial
    {
        get => _serial;
        set
        {
            if (SetProperty(ref _serial, value))
            {
                OnPropertyChanged(nameof(CanSubmit));
            }
        }
    }

    public string BindToken
    {
        get => _bindToken;
        set => SetProperty(ref _bindToken, value);
    }

    public string IdentityPath
    {
        get => _identityPath;
        set => SetProperty(ref _identityPath, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
            {
                OnPropertyChanged(nameof(CanSubmit));
            }
        }
    }

    public string? ErrorMessage
    {
        get => _errorMessage;
        private set => SetProperty(ref _errorMessage, value);
    }

    public string? SuccessMessage
    {
        get => _successMessage;
        private set => SetProperty(ref _successMessage, value);
    }

    public IReadOnlyList<string> Serials
    {
        get => _serials;
        private set => SetProperty(ref _serials, value);
    }

    public bool CanSubmit =>
        !IsBusy && !string.IsNullOrWhiteSpace(_userToken) && !string.IsNullOrWhiteSpace(Serial);

    /// <summary>
    /// PasswordBox/PasswordEntry are not bindable, so the view passes the value
    /// here on every change.
    /// </summary>
    public void SetToken(string token)
    {
        _userToken = token ?? string.Empty;
        OnPropertyChanged(nameof(CanSubmit));
    }

    public async Task SubmitAsync(CancellationToken cancellationToken = default)
    {
        if (!CanSubmit)
        {
            return;
        }

        IsBusy = true;
        ErrorMessage = null;
        SuccessMessage = null;

        try
        {
            var result = await _client
                .ProvisionAsync(
                    _userToken,
                    Serial,
                    string.IsNullOrWhiteSpace(BindToken) ? null : BindToken,
                    IdentityPath,
                    cancellationToken: cancellationToken)
                .ConfigureAwait(true);

            Serials = result.Serials;
            SuccessMessage =
                $"Identität gespeichert für {string.Join(", ", result.Serials)}.";

            // The Plaud cookie is single-use; do not keep it around.
            _userToken = string.Empty;
            OnPropertyChanged(nameof(CanSubmit));
        }
        catch (PlaudOnboardingException error)
        {
            ErrorMessage = error.Message;
        }
        catch (OperationCanceledException)
        {
            ErrorMessage = "Einrichtung abgebrochen.";
        }
        catch (Exception error)
        {
            ErrorMessage = $"Unerwarteter Fehler: {error.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }
        field = value;
        OnPropertyChanged(name);
        return true;
    }

    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
