using System.ComponentModel;
using System.Runtime.CompilerServices;
using Plaud.App.Services;

namespace Plaud.App.ViewModels;

public sealed class SettingsViewModel : INotifyPropertyChanged
{
    private readonly SettingsService _settings;
    private string _baseUrl;
    private string _apiKey;
    private string _sttModel;
    private string _chatModel;
    private string? _status;

    public SettingsViewModel(SettingsService settings)
    {
        _settings = settings;
        _baseUrl = settings.BitAi.BaseUrl;
        _apiKey = settings.BitAi.ApiKey ?? string.Empty;
        _sttModel = settings.BitAi.SttModel;
        _chatModel = settings.BitAi.ChatModel;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public string BaseUrl
    {
        get => _baseUrl;
        set => Set(ref _baseUrl, value);
    }

    public string ApiKey
    {
        get => _apiKey;
        set => Set(ref _apiKey, value);
    }

    public string SttModel
    {
        get => _sttModel;
        set => Set(ref _sttModel, value);
    }

    public string ChatModel
    {
        get => _chatModel;
        set => Set(ref _chatModel, value);
    }

    public string? Status
    {
        get => _status;
        private set => Set(ref _status, value);
    }

    public void Save()
    {
        _settings.BitAi.BaseUrl = BaseUrl.Trim();
        _settings.BitAi.ApiKey = string.IsNullOrWhiteSpace(ApiKey) ? null : ApiKey.Trim();
        _settings.BitAi.SttModel = string.IsNullOrWhiteSpace(SttModel) ? "whisper-1" : SttModel.Trim();
        _settings.BitAi.ChatModel = string.IsNullOrWhiteSpace(ChatModel)
            ? "deepseek-v4-1-flash-1017-r"
            : ChatModel.Trim();
        _settings.Save();
        Status = "Einstellungen gespeichert.";
    }

    public void SetApiKey(string value)
    {
        ApiKey = value;
    }

    private void Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return;
        }
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
