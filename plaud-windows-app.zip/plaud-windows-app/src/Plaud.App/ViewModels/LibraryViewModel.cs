using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json;
using Plaud.BitAi;
using Plaud.Core;

namespace Plaud.App.ViewModels;

public sealed class LibraryViewModel : INotifyPropertyChanged
{
    private readonly RecordingService _service;
    private readonly PlaudStore _store;
    private Recording? _selected;
    private string? _message;
    private string? _answer;
    private bool _isBusy;
    private string _search = string.Empty;

    public LibraryViewModel(RecordingService service, PlaudStore store)
    {
        _service = service;
        _store = store;
        Refresh();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public ObservableCollection<Recording> Recordings { get; } = new();

    public IReadOnlyList<SummaryTemplate> Templates => SummaryTemplates.All;

    public Recording? Selected
    {
        get => _selected;
        set
        {
            if (Set(ref _selected, value))
            {
                Raise(nameof(Transcript));
                Raise(nameof(Summary));
                Raise(nameof(HasSelection));
                Raise(nameof(SelectedTitle));
            }
        }
    }

    public bool HasSelection => Selected is not null;
    public string SelectedTitle => Selected?.Title ?? "Keine Aufnahme ausgewählt";
    public string Transcript => Selected?.Transcript ?? "Noch kein Transkript.";
    public string Summary => PrettySummary(Selected?.SummaryJson);
    public string? Message { get => _message; private set => Set(ref _message, value); }
    public string? Answer { get => _answer; private set => Set(ref _answer, value); }
    public bool IsBusy { get => _isBusy; private set => Set(ref _isBusy, value); }

    public string Search
    {
        get => _search;
        set
        {
            if (Set(ref _search, value))
            {
                Refresh();
            }
        }
    }

    public void Refresh()
    {
        var selectedId = Selected?.Id;
        Recordings.Clear();
        foreach (var recording in _store.List(Search))
        {
            Recordings.Add(recording);
        }
        Selected = selectedId is null
            ? Recordings.FirstOrDefault()
            : Recordings.FirstOrDefault(recording => recording.Id == selectedId)
              ?? Recordings.FirstOrDefault();
    }

    public async Task ImportAsync(Stream audio, string fileName)
    {
        IsBusy = true;
        Message = null;
        try
        {
            var extension = Path.GetExtension(fileName);
            var recording = await _service.ImportAsync(
                audio,
                Path.GetFileNameWithoutExtension(fileName),
                string.IsNullOrEmpty(extension) ? ".ogg" : extension);
            Refresh();
            Selected = Recordings.FirstOrDefault(item => item.Id == recording.Id);
            Message = "Aufnahme importiert.";
        }
        catch (Exception error)
        {
            Message = error.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    public async Task TranscribeAsync()
    {
        if (Selected is null)
        {
            return;
        }
        await RunAsync(
            recording => _service.TranscribeAsync(recording.Id),
            "Transkription abgeschlossen.");
    }

    public async Task SummarizeAsync(string templateId)
    {
        if (Selected is null)
        {
            return;
        }
        await RunAsync(
            recording => _service.SummarizeAsync(recording.Id, templateId),
            "Zusammenfassung erstellt.");
    }

    public async Task AskAsync(string question)
    {
        if (Selected is null || string.IsNullOrWhiteSpace(question))
        {
            return;
        }
        IsBusy = true;
        Message = null;
        Answer = null;
        try
        {
            Answer = await _service.AskAsync(Selected.Id, question);
        }
        catch (Exception error)
        {
            Message = error.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    public void DeleteSelected()
    {
        if (Selected is null)
        {
            return;
        }
        _service.Delete(Selected.Id);
        Selected = null;
        Refresh();
        Message = "Aufnahme gelöscht.";
    }

    private async Task RunAsync(Func<Recording, Task<Recording>> operation, string success)
    {
        if (Selected is null)
        {
            return;
        }
        IsBusy = true;
        Message = null;
        try
        {
            await operation(Selected);
            Refresh();
            Message = success;
        }
        catch (Exception error)
        {
            Message = error.Message;
            Refresh();
        }
        finally
        {
            IsBusy = false;
        }
    }

    private static string PrettySummary(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return "Noch keine Zusammenfassung.";
        }
        try
        {
            using var document = JsonDocument.Parse(json);
            return JsonSerializer.Serialize(
                document.RootElement,
                new JsonSerializerOptions { WriteIndented = true });
        }
        catch (JsonException)
        {
            return json;
        }
    }

    private bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }
        field = value;
        Raise(name);
        return true;
    }

    private void Raise(string? name) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
