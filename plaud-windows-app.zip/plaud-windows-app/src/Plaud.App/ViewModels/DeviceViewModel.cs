using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Plaud.Ble.Windows;
using Plaud.Core;
using PlaudOnboarding;

namespace Plaud.App.ViewModels;

public sealed class DeviceViewModel : INotifyPropertyChanged
{
    private readonly PlaudBleClient _client;
    private readonly RecordingService _service;
    private PlaudDeviceInfo? _selectedDevice;
    private string? _status;
    private string? _message;
    private string? _transfer;
    private bool _isBusy;

    public DeviceViewModel(PlaudBleClient client, RecordingService service)
    {
        _client = client;
        _service = service;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public ObservableCollection<PlaudDeviceInfo> Devices { get; } = new();
    public ObservableCollection<PlaudSession> Sessions { get; } = new();

    public PlaudDeviceInfo? SelectedDevice
    {
        get => _selectedDevice;
        set => Set(ref _selectedDevice, value);
    }

    public string? Status { get => _status; private set => Set(ref _status, value); }
    public string? Message { get => _message; private set => Set(ref _message, value); }
    public string? Transfer { get => _transfer; private set => Set(ref _transfer, value); }
    public bool IsBusy { get => _isBusy; private set => Set(ref _isBusy, value); }
    public bool IsConnected => _client.IsConnected;

    public async Task ScanAsync()
    {
        IsBusy = true;
        Message = null;
        Status = "Suche nach Plaud-Geräten …";
        try
        {
            Devices.Clear();
            var found = await _client.ScanAsync(TimeSpan.FromSeconds(10));
            foreach (var device in found)
            {
                Devices.Add(device);
            }
            SelectedDevice = Devices.FirstOrDefault();
            Status = found.Count == 0
                ? "Kein Gerät gefunden. Gerät aufwecken und Bluetooth am Handy ausschalten."
                : $"{found.Count} Gerät(e) gefunden.";
        }
        catch (Exception error)
        {
            Message = error.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    public async Task ConnectAsync()
    {
        if (SelectedDevice is null)
        {
            Message = "Bitte zuerst ein Gerät auswählen.";
            return;
        }

        var identity = PlaudIdentityStore.Load(AppPaths.Identity);
        if (identity is null || identity.Accounts.Count == 0)
        {
            Message = "Bitte zuerst das Plaud-Konto einrichten.";
            return;
        }

        var account =
            identity.Accounts.Values.FirstOrDefault(candidate =>
                candidate.SnSignature.ContainsKey(SelectedDevice.Serial))
            ?? identity.Accounts.Values.First();

        IsBusy = true;
        Message = null;
        Status = "Verbinde …";
        try
        {
            await _client.ConnectAsync(SelectedDevice, account);
            Status = _client.Handshake is { } handshake
                ? $"Verbunden · Protokoll {handshake.PortVersion} · {handshake.Channels} Kanal/Kanäle"
                : "Verbunden.";
            await LoadSessionsAsync();
        }
        catch (Exception error)
        {
            Message = error.Message;
            Status = "Nicht verbunden.";
        }
        finally
        {
            IsBusy = false;
            Raise(nameof(IsConnected));
        }
    }

    public async Task LoadSessionsAsync()
    {
        if (!_client.IsConnected)
        {
            return;
        }
        IsBusy = true;
        Message = null;
        try
        {
            Sessions.Clear();
            foreach (var session in await _client.ListSessionsAsync())
            {
                Sessions.Add(session);
            }
            Status = Sessions.Count == 0
                ? "Keine Aufnahmen auf dem Gerät."
                : $"{Sessions.Count} Aufnahme(n) auf dem Gerät.";
        }
        catch (Exception error)
        {
            Message = error.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    public async Task DownloadAsync(PlaudSession session)
    {
        IsBusy = true;
        Message = null;
        Transfer = null;
        try
        {
            var progress = new Progress<uint>(bytes => Transfer = $"{bytes:N0} Bytes übertragen");
            var audio = await _client.DownloadAsync(session, progress);
            using var stream = new MemoryStream(audio);
            var recording = await _service.ImportAsync(
                stream,
                $"Plaud {session.RecordedAt.LocalDateTime:yyyy-MM-dd HH-mm}",
                ".ogg",
                session.SessionId.ToString());

            Status = "Aufnahme heruntergeladen, Transkription läuft …";
            await _service.TranscribeAsync(recording.Id);
            Status = "Aufnahme heruntergeladen und transkribiert.";
        }
        catch (Exception error)
        {
            Message = error.Message;
        }
        finally
        {
            IsBusy = false;
            Transfer = null;
        }
    }

    public void Disconnect()
    {
        _client.Disconnect();
        Sessions.Clear();
        Status = "Nicht verbunden.";
        Raise(nameof(IsConnected));
    }

    private bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }
        field = value;
        Raise(name);
        return true;
    }

    private void Raise(string? name) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
