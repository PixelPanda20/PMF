using Plaud.BitAi;
using Plaud.Core;
using Windows.Security.Credentials;

namespace Plaud.App.Services;

/// <summary>Persists BIT-AI configuration in the local SQLite settings table.</summary>
public sealed class SettingsService
{
    private readonly PlaudStore _store;

    public SettingsService(PlaudStore store)
    {
        _store = store;
    }

    public BitAiOptions BitAi { get; } = new();

    public void Load()
    {
        BitAi.BaseUrl = _store.GetSetting("bitai.baseUrl") ?? string.Empty;
        BitAi.ApiKey = ReadApiKey() ?? string.Empty;
        BitAi.SttModel = _store.GetSetting("bitai.sttModel") ?? "whisper-1";
        BitAi.ChatModel = _store.GetSetting("bitai.chatModel") ?? "deepseek-v4-1-flash-1017-r";
    }

    public void Save()
    {
        _store.SetSetting("bitai.baseUrl", BitAi.BaseUrl?.Trim() ?? string.Empty);
        WriteApiKey(BitAi.ApiKey);
        _store.SetSetting("bitai.sttModel", BitAi.SttModel);
        _store.SetSetting("bitai.chatModel", BitAi.ChatModel);
    }

    /// <summary>The API key lives in the Windows Credential Locker, not in SQLite.</summary>
    private static string? ReadApiKey()
    {
        try
        {
            var vault = new PasswordVault();
            var credential = vault.Retrieve("PlaudRecorder", "bitai");
            credential.RetrievePassword();
            return credential.Password;
        }
        catch
        {
            return null;
        }
    }

    private static void WriteApiKey(string? key)
    {
        try
        {
            var vault = new PasswordVault();
            try
            {
                var existing = vault.Retrieve("PlaudRecorder", "bitai");
                vault.Remove(existing);
            }
            catch
            {
                // no entry yet
            }
            if (!string.IsNullOrWhiteSpace(key))
            {
                vault.Add(new PasswordCredential("PlaudRecorder", "bitai", key));
            }
        }
        catch
        {
            // Credential Locker unavailable (e.g. unpackaged) – keep it in memory only.
        }
    }
}
