using Microsoft.Extensions.DependencyInjection;
using Plaud.App.ViewModels;
using Plaud.BitAi;
using Plaud.Ble.Windows;
using Plaud.Core;
using PlaudOnboarding;
using PlaudOnboarding.ViewModels;

namespace Plaud.App.Services;

/// <summary>Composition root. One instance per process; no global mutable state beyond services.</summary>
public static class AppServices
{
    private static ServiceProvider? _provider;

    public static void Initialize()
    {
        if (_provider is not null)
        {
            return;
        }

        var store = new PlaudStore(AppPaths.Database);
        store.Initialize();
        var audio = new AudioStore(AppPaths.Audio);
        var settings = new SettingsService(store);
        settings.Load();

        var services = new ServiceCollection();
        services.AddSingleton(store);
        services.AddSingleton(audio);
        services.AddSingleton(settings);
        services.AddSingleton(settings.BitAi);
        services.AddSingleton(_ => new HttpClient { Timeout = TimeSpan.FromMinutes(20) });
        services.AddSingleton<BitAiClient>();
        services.AddSingleton(sp => new RecordingService(
            store,
            audio,
            sp.GetRequiredService<BitAiClient>(),
            sp.GetRequiredService<BitAiClient>()));
        services.AddSingleton<PlaudBleClient>();
        services.AddTransient<LibraryViewModel>();
        services.AddTransient<DeviceViewModel>();
        services.AddTransient<SettingsViewModel>();
        services.AddTransient(_ => new OnboardingViewModel(
            new PlaudOnboardingClient(new HttpClient { Timeout = TimeSpan.FromMinutes(2) }),
            AppPaths.Identity));

        _provider = services.BuildServiceProvider();
    }

    public static T Get<T>() where T : notnull =>
        (_provider ?? throw new InvalidOperationException("AppServices not initialized."))
        .GetRequiredService<T>();
}
