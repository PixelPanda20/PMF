using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Plaud.App.Services;
using PlaudOnboarding.ViewModels;

namespace Plaud.App.Pages;

public sealed partial class OnboardingPage : Page
{
    public OnboardingViewModel ViewModel { get; } = AppServices.Get<OnboardingViewModel>();

    public OnboardingPage()
    {
        InitializeComponent();
    }

    private void Token_PasswordChanged(object sender, RoutedEventArgs e) =>
        ViewModel.SetToken(((PasswordBox)sender).Password);

    private async void Submit_Click(object sender, RoutedEventArgs e) => await ViewModel.SubmitAsync();
}
