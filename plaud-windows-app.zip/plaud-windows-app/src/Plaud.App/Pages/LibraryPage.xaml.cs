using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Plaud.App.Services;
using Plaud.App.ViewModels;
using Plaud.BitAi;
using Plaud.Core;
using Windows.Storage;
using Windows.Storage.Pickers;
using WinRT.Interop;

namespace Plaud.App.Pages;

public sealed partial class LibraryPage : Page
{
    public LibraryViewModel ViewModel { get; } = AppServices.Get<LibraryViewModel>();

    public LibraryPage()
    {
        InitializeComponent();
        TemplateBox.ItemsSource = ViewModel.Templates;
        TemplateBox.SelectedIndex = 0;
    }

    private void Search_TextChanged(object sender, TextChangedEventArgs e)
    {
        ViewModel.Search = SearchBox.Text;
    }

    private async void Recordings_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var recording = RecordingsList.SelectedItem as Recording;
        ViewModel.Selected = recording;
        if (recording is null)
        {
            Player.Source = null;
            return;
        }
        var file = await StorageFile.GetFileFromPathAsync(recording.AudioPath);
        Player.Source = Windows.Media.Core.MediaSource.CreateFromStorageFile(file);
    }

    private async void Import_Click(object sender, RoutedEventArgs e)
    {
        var picker = new FileOpenPicker
        {
            SuggestedStartLocation = PickerLocationId.MusicLibrary
        };
        foreach (var extension in new[] { ".ogg", ".opus", ".mp3", ".wav", ".m4a", ".flac", ".aac" })
        {
            picker.FileTypeFilter.Add(extension);
        }
        if (App.MainWindow is { } window)
        {
            InitializeWithWindow.Initialize(picker, WindowNative.GetWindowHandle(window));
        }

        var file = await picker.PickSingleFileAsync();
        if (file is null)
        {
            return;
        }

        await using var stream = await file.OpenStreamForReadAsync();
        await ViewModel.ImportAsync(stream, file.Name);
    }

    private async void Transcribe_Click(object sender, RoutedEventArgs e)
    {
        await ViewModel.TranscribeAsync();
    }

    private async void Summarize_Click(object sender, RoutedEventArgs e)
    {
        var template = TemplateBox.SelectedItem as SummaryTemplate;
        await ViewModel.SummarizeAsync(template?.Id ?? "standard");
    }

    private async void Ask_Click(object sender, RoutedEventArgs e)
    {
        await ViewModel.AskAsync(QuestionBox.Text);
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        ViewModel.DeleteSelected();
    }
}
