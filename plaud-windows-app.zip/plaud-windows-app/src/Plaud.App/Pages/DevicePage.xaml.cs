using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Plaud.App.Services;
using Plaud.App.ViewModels;
using Plaud.Ble.Windows;

namespace Plaud.App.Pages;

public sealed partial class DevicePage : Page
{
    public DeviceViewModel ViewModel { get; } = AppServices.Get<DeviceViewModel>();

    public DevicePage()
    {
        InitializeComponent();
    }

    private async void Scan_Click(object sender, RoutedEventArgs e) => await ViewModel.ScanAsync();

    private async void Connect_Click(object sender, RoutedEventArgs e) => await ViewModel.ConnectAsync();

    private void Disconnect_Click(object sender, RoutedEventArgs e) => ViewModel.Disconnect();

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await ViewModel.LoadSessionsAsync();

    private void Devices_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
        ViewModel.SelectedDevice = DevicesList.SelectedItem as PlaudDeviceInfo;

    private async void Download_Click(object sender, RoutedEventArgs e)
    {
        if (SessionsList.SelectedItem is PlaudSession session)
        {
            await ViewModel.DownloadAsync(session);
        }
    }

    private void Sessions_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // selection is read on demand in Download_Click
    }

    private void Onboarding_Click(object sender, RoutedEventArgs e) =>
        Frame.Navigate(typeof(OnboardingPage));
}
