using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Plaud.App.Services;
using Plaud.App.ViewModels;

namespace Plaud.App.Pages;

public sealed partial class SettingsPage : Page
{
    public SettingsViewModel ViewModel { get; } = AppServices.Get<SettingsViewModel>();

    public SettingsPage()
    {
        InitializeComponent();
        ApiKeyBox.Password = ViewModel.ApiKey;
    }

    private void ApiKey_PasswordChanged(object sender, RoutedEventArgs e)
    {
        ViewModel.SetApiKey(((PasswordBox)sender).Password);
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        ViewModel.Save();
    }
}
