using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Plaud.Core;

namespace Plaud.BitAi;

/// <summary>
/// BIT-AI client: Whisper-compatible transcription and Chat-Completions
/// summaries/Q&amp;A. Prompts and JSON schema mirror the reference app.
/// </summary>
public sealed class BitAiClient : ITranscriber, ISummarizer
{
    private const int MaxDirectChars = 24_000;
    private const int PartChars = 18_000;

    private const string SummarySchema =
        """
        {"summary":"string – 3 bis 6 Sätze","key_points":["string"],"decisions":["string"],
        "todos":[{"task":"string","owner":"string|null","due":"string|null"}],
        "participants":["string"],"topics":["string"],"language":"ISO-639-1"}
        """;

    private const string BasePrompt =
        "Du bist ein Protokoll-Assistent der Schweizer Bundesverwaltung. " +
        "Du fasst Transkripte von Besprechungen sachlich und auf Deutsch zusammen. " +
        "Erfinde keine Inhalte: Wenn eine Angabe im Transkript fehlt, lass das Feld leer. " +
        "Antworte ausschliesslich mit JSON, ohne Markdown und ohne Kommentare. " +
        "JSON-Schema: " + SummarySchema;

    private const string PartPrompt =
        "Fasse den folgenden Transkript-Abschnitt als Stichpunkte zusammen. " +
        "Nenne Entscheide und Aufgaben mit den im Text genannten Namen. " +
        "Antworte ausschliesslich mit JSON: {\"notes\": [\"...\"]}";

    private readonly HttpClient _http;
    private readonly BitAiOptions _options;

    public BitAiClient(HttpClient http, BitAiOptions options)
    {
        _http = http;
        _options = options;
    }

    public async Task<TranscriptResult> TranscribeAsync(
        Stream audio,
        string fileName,
        string? language,
        CancellationToken cancellationToken = default)
    {
        EnsureConfigured();

        using var form = new MultipartFormDataContent();
        var file = new StreamContent(audio);
        file.Headers.ContentType = new MediaTypeHeaderValue("audio/ogg");
        form.Add(file, "file", fileName);
        form.Add(new StringContent(_options.SttModel), "model");
        form.Add(new StringContent("verbose_json"), "response_format");
        if (!string.IsNullOrWhiteSpace(language))
        {
            form.Add(new StringContent(language), "language");
        }

        using var request = new HttpRequestMessage(
            HttpMethod.Post,
            BuildUri("/audio/transcriptions"))
        {
            Content = form
        };
        AddAuthorization(request);

        using var response = await SendAsync(request, cancellationToken).ConfigureAwait(false);
        var body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            throw new BitAiException(
                $"Transkription fehlgeschlagen (HTTP {(int)response.StatusCode}): {Trim(body)}",
                (int)response.StatusCode);
        }

        using var document = JsonDocument.Parse(body);
        var root = document.RootElement;
        var text = root.TryGetProperty("text", out var textValue) ? textValue.GetString() ?? "" : "";
        var detectedLanguage = root.TryGetProperty("language", out var languageValue)
            ? languageValue.GetString()
            : null;
        double? duration = root.TryGetProperty("duration", out var durationValue) &&
                           durationValue.TryGetDouble(out var parsedDuration)
            ? parsedDuration
            : null;

        var segments = new List<TranscriptSegment>();
        if (root.TryGetProperty("segments", out var segmentArray) &&
            segmentArray.ValueKind == JsonValueKind.Array)
        {
            foreach (var segment in segmentArray.EnumerateArray())
            {
                segments.Add(
                    new TranscriptSegment(
                        ReadDouble(segment, "start"),
                        ReadDouble(segment, "end"),
                        segment.TryGetProperty("text", out var segmentText)
                            ? (segmentText.GetString() ?? "").Trim()
                            : string.Empty));
            }
        }

        if (segments.Count == 0 && !string.IsNullOrWhiteSpace(text))
        {
            segments.Add(new TranscriptSegment(0, duration ?? 0, text.Trim()));
        }

        var combined = string.IsNullOrWhiteSpace(text)
            ? string.Join(" ", segments.Select(segment => segment.Text)).Trim()
            : text.Trim();

        return new TranscriptResult(combined, detectedLanguage, duration, segments);
    }

    public async Task<string> SummarizeAsync(
        string transcript,
        string templateId,
        CancellationToken cancellationToken = default)
    {
        EnsureConfigured();
        if (string.IsNullOrWhiteSpace(transcript))
        {
            throw new BitAiException("Das Transkript ist leer.");
        }

        var template = SummaryTemplates.Find(templateId);
        var systemPrompt = string.IsNullOrEmpty(template.Focus)
            ? BasePrompt
            : BasePrompt + " Zusätzlicher Fokus: " + template.Focus;

        if (transcript.Length <= MaxDirectChars)
        {
            return await CompleteAsync(
                    systemPrompt,
                    transcript,
                    2000,
                    cancellationToken)
                .ConfigureAwait(false);
        }

        // Long transcripts: condense each part, then run the final JSON call on
        // the notes (same two-stage approach as the reference implementation).
        var notes = new List<string>();
        foreach (var part in Split(transcript, PartChars))
        {
            var partial = await CompleteAsync(
                    PartPrompt,
                    part,
                    1200,
                    cancellationToken)
                .ConfigureAwait(false);
            notes.AddRange(ReadNotes(partial));
        }

        var combined = string.Join("\n- ", notes);
        return await CompleteAsync(
                systemPrompt,
                "Stichpunkte aus dem Transkript:\n- " + combined,
                2000,
                cancellationToken)
            .ConfigureAwait(false);
    }

    public async Task<string> AskAsync(
        string question,
        string transcript,
        string? summaryJson,
        CancellationToken cancellationToken = default)
    {
        EnsureConfigured();
        if (string.IsNullOrWhiteSpace(question))
        {
            throw new BitAiException("Die Frage ist leer.");
        }

        var context = string.IsNullOrWhiteSpace(summaryJson)
            ? transcript
            : "Zusammenfassung (JSON):\n" + summaryJson + "\n\nTranskript:\n" + transcript;

        return await CompleteAsync(
                "Du beantwortest Fragen ausschliesslich anhand des bereitgestellten Transkripts. " +
                "Wenn die Antwort nicht enthalten ist, sage das klar. Antworte knapp auf Deutsch.",
                context + "\n\nFrage: " + question,
                800,
                cancellationToken)
            .ConfigureAwait(false);
    }

    private async Task<string> CompleteAsync(
        string systemPrompt,
        string userPrompt,
        int maxTokens,
        CancellationToken cancellationToken)
    {
        var payload = JsonSerializer.Serialize(
            new
            {
                model = _options.ChatModel,
                temperature = 0.2,
                max_tokens = maxTokens,
                messages = new[]
                {
                    new { role = "system", content = systemPrompt },
                    new { role = "user", content = userPrompt }
                }
            });

        using var request = new HttpRequestMessage(
            HttpMethod.Post,
            BuildUri("/chat/completions"))
        {
            Content = new StringContent(payload, Encoding.UTF8, "application/json")
        };
        AddAuthorization(request);

        using var response = await SendAsync(request, cancellationToken).ConfigureAwait(false);
        var body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            throw new BitAiException(
                $"BIT-AI antwortete mit HTTP {(int)response.StatusCode}: {Trim(body)}",
                (int)response.StatusCode);
        }

        using var document = JsonDocument.Parse(body);
        try
        {
            return document.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString() ?? string.Empty;
        }
        catch (Exception error) when (error is KeyNotFoundException or IndexOutOfRangeException)
        {
            throw new BitAiException("Unerwartete BIT-AI-Antwortstruktur.");
        }
    }

    private async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(_options.Timeout);
        try
        {
            return await _http.SendAsync(request, timeout.Token).ConfigureAwait(false);
        }
        catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new BitAiException("BIT-AI hat nicht rechtzeitig geantwortet.");
        }
        catch (HttpRequestException error)
        {
            throw new BitAiException($"BIT-AI nicht erreichbar: {error.Message}");
        }
    }

    private void EnsureConfigured()
    {
        if (!_options.IsConfigured)
        {
            throw new BitAiException(
                "BIT-AI ist nicht konfiguriert (BaseUrl fehlt in den Einstellungen).");
        }
    }

    private Uri BuildUri(string path) =>
        new(_options.BaseUrl.TrimEnd('/') + path);

    private void AddAuthorization(HttpRequestMessage request)
    {
        if (!string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _options.ApiKey);
        }
    }

    private static double ReadDouble(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.TryGetDouble(out var parsed)
            ? parsed
            : 0;

    private static IReadOnlyList<string> ReadNotes(string raw)
    {
        try
        {
            var json = ExtractJsonObject(raw);
            using var document = JsonDocument.Parse(json);
            if (document.RootElement.TryGetProperty("notes", out var notes) &&
                notes.ValueKind == JsonValueKind.Array)
            {
                return notes.EnumerateArray()
                    .Select(note => note.GetString())
                    .Where(note => !string.IsNullOrWhiteSpace(note))
                    .Select(note => note!)
                    .ToList();
            }
        }
        catch (JsonException)
        {
            // fall through: keep the raw text as a single note
        }
        return new[] { raw.Trim() };
    }

    private static string ExtractJsonObject(string raw)
    {
        var cleaned = raw.Trim();
        if (cleaned.StartsWith("```", StringComparison.Ordinal))
        {
            var firstLine = cleaned.IndexOf('\n');
            if (firstLine >= 0)
            {
                cleaned = cleaned[(firstLine + 1)..];
            }
            var fence = cleaned.LastIndexOf("```", StringComparison.Ordinal);
            if (fence >= 0)
            {
                cleaned = cleaned[..fence];
            }
        }
        var start = cleaned.IndexOf('{');
        var end = cleaned.LastIndexOf('}');
        return start >= 0 && end > start ? cleaned[start..(end + 1)] : cleaned;
    }

    internal static IReadOnlyList<string> Split(string text, int size)
    {
        if (text.Length <= size)
        {
            return new[] { text };
        }

        var parts = new List<string>();
        var remaining = text;
        while (remaining.Length > size)
        {
            var cut = remaining.LastIndexOf(". ", size, StringComparison.Ordinal);
            if (cut < size / 2)
            {
                cut = remaining.LastIndexOf(' ', size);
            }
            if (cut <= 0)
            {
                cut = size;
            }
            else
            {
                cut += 1;
            }
            parts.Add(remaining[..cut].Trim());
            remaining = remaining[cut..].TrimStart();
        }
        if (remaining.Length > 0)
        {
            parts.Add(remaining);
        }
        return parts;
    }

    private static string Trim(string value) =>
        value.Length <= 300 ? value : value[..300] + "…";
}
