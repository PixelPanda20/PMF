using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Plaud.BitAi;

public sealed class BitAiOptions
{
    /// <summary>Base URL of the OpenAI-compatible gateway, e.g. https://bitai.example/v1.</summary>
    public string BaseUrl { get; set; } = string.Empty;

    public string? ApiKey { get; set; }
    public string SttModel { get; set; } = "whisper-1";
    public string ChatModel { get; set; } = "deepseek-v4-1-flash-1017-r";
    public TimeSpan Timeout { get; set; } = TimeSpan.FromMinutes(15);

    public bool IsConfigured => !string.IsNullOrWhiteSpace(BaseUrl);
}

public sealed class BitAiException : Exception
{
    public int? HttpStatus { get; }

    public BitAiException(string message, int? httpStatus = null)
        : base(message)
    {
        HttpStatus = httpStatus;
    }
}

public sealed record SummaryTemplate(string Id, string Label, string Focus);

public static class SummaryTemplates
{
    public static IReadOnlyList<SummaryTemplate> All { get; } = new[]
    {
        new SummaryTemplate("standard", "Besprechung", string.Empty),
        new SummaryTemplate(
            "interview",
            "Interview",
            "Fokus: Kernaussagen der interviewten Person, Fragen und Antworten, " +
            "wörtliche Zitate nur wenn sie im Transkript stehen."),
        new SummaryTemplate(
            "telefonat",
            "Telefonat",
            "Fokus: Anliegen des Anrufs, getroffene Vereinbarungen, nächste Schritte, Fristen."),
        new SummaryTemplate(
            "workshop",
            "Workshop",
            "Fokus: gesammelte Ideen, diskutierte Optionen, Entscheidungskriterien, offene Punkte."),
        new SummaryTemplate(
            "entscheid",
            "Entscheidungsprotokoll",
            "Fokus: getroffene Entscheide mit Begründung, verworfene Alternativen, " +
            "Verantwortliche und Termine.")
    };

    public static SummaryTemplate Find(string id) =>
        All.FirstOrDefault(template => template.Id == id) ?? All[0];
}
