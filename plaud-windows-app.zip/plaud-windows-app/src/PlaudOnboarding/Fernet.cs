using System.Security.Cryptography;

namespace PlaudOnboarding;

/// <summary>
/// Fernet (AES-128-CBC + HMAC-SHA256) as used for encrypted Plaud responses.
///
/// Token layout: version (0x80) | timestamp (8) | IV (16) | ciphertext | HMAC (32).
/// The 32-byte secret is split into a 16-byte signing and a 16-byte encryption key.
/// </summary>
internal static class Fernet
{
    public static byte[] Decrypt(string token, string key)
    {
        var raw = Base64Url.Decode(token);
        if (raw.Length < 1 + 8 + 16 + 32 || raw[0] != 0x80)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.Decryption,
                "Verschlüsselte Plaud-Antwort ist ungültig.");
        }

        var secret = Base64Url.Decode(key);
        if (secret.Length != 32)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.Decryption,
                "Fernet-Schlüssel ist ungültig.");
        }

        var signingKey = secret[..16];
        var encryptionKey = secret[16..];
        var signed = raw[..^32];
        var signature = raw[^32..];

        using var hmac = new HMACSHA256(signingKey);
        var expected = hmac.ComputeHash(signed);
        if (!CryptographicOperations.FixedTimeEquals(expected, signature))
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.Decryption,
                "Signatur der Plaud-Antwort stimmt nicht.");
        }

        using var aes = Aes.Create();
        aes.Key = encryptionKey;
        aes.IV = raw[9..25];
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.PKCS7;
        using var decryptor = aes.CreateDecryptor();
        var ciphertext = raw[25..^32];
        return decryptor.TransformFinalBlock(ciphertext, 0, ciphertext.Length);
    }
}
