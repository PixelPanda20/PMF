using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace PlaudOnboarding;

internal sealed record PlaudApiResponse(JsonElement Body, Uri BaseUri);

/// <summary>Thin client for the Plaud device API used during onboarding.</summary>
internal sealed class PlaudApi
{
    private readonly HttpClient _http;

    public PlaudApi(HttpClient http)
    {
        _http = http;
    }

    public async Task<PlaudApiResponse> PostAsync(
        string path,
        object payload,
        string token,
        Uri baseUri,
        int redirects = 0,
        CancellationToken cancellationToken = default)
    {
        var uri = new Uri(baseUri, path.TrimStart('/'));
        using var request = new HttpRequestMessage(HttpMethod.Post, uri);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Headers.TryAddWithoutValidation("app-platform", "android");
        request.Headers.TryAddWithoutValidation("X-Encrypt-Response", "1");
        request.Content = new StringContent(
            JsonSerializer.Serialize(payload),
            Encoding.UTF8,
            "application/json");

        HttpResponseMessage response;
        try
        {
            response = await _http.SendAsync(request, cancellationToken).ConfigureAwait(false);
        }
        catch (HttpRequestException error)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.InvalidResponse,
                $"Plaud-API nicht erreichbar: {error.Message}");
        }
        catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.InvalidResponse,
                "Plaud-API hat nicht rechtzeitig geantwortet.");
        }

        using (response)
        {
            if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                throw new PlaudOnboardingException(
                    PlaudErrorCode.InvalidToken,
                    "Plaud-Token ungültig oder abgelaufen (pld_ut-Cookie von web.plaud.ai).");
            }
            if ((int)response.StatusCode >= 400)
            {
                throw new PlaudOnboardingException(
                    PlaudErrorCode.Api,
                    $"Plaud-API antwortete mit HTTP {(int)response.StatusCode}.",
                    (int)response.StatusCode);
            }

            var bytes = await response.Content.ReadAsByteArrayAsync(cancellationToken)
                .ConfigureAwait(false);
            var encrypted = response.Headers.TryGetValues("x-encrypt-response", out var values)
                && values.Any(value => value.Trim() == "1");

            if (encrypted)
            {
                var text = Encoding.UTF8.GetString(bytes).Trim();
                bytes = Fernet.Decrypt(text, PlaudOnboardingClient.AppFernetKey);
            }

            JsonDocument document;
            try
            {
                document = JsonDocument.Parse(bytes);
            }
            catch (JsonException)
            {
                throw new PlaudOnboardingException(
                    PlaudErrorCode.InvalidResponse,
                    "Plaud-Antwort ist kein JSON.");
            }

            using (document)
            {
                var body = document.RootElement.Clone();
                var code = ReadCode(body);
                if (code == -302)
                {
                    var region = RegionBase(body);
                    if (region is not null && redirects < 2 && region != baseUri)
                    {
                        return await PostAsync(
                                path,
                                payload,
                                token,
                                region,
                                redirects + 1,
                                cancellationToken)
                            .ConfigureAwait(false);
                    }
                    throw new PlaudOnboardingException(
                        PlaudErrorCode.InvalidResponse,
                        "Plaud-API verlangt eine andere Region.");
                }
                if (code is not null and not 0)
                {
                    throw new PlaudOnboardingException(
                        PlaudErrorCode.ApiCode,
                        $"Plaud-API-Fehler {code}.");
                }

                return new PlaudApiResponse(body, baseUri);
            }
        }
    }

    private static int? ReadCode(JsonElement body)
    {
        if (body.ValueKind != JsonValueKind.Object)
        {
            return null;
        }
        if (body.TryGetProperty("code", out var code) && code.TryGetInt32(out var value))
        {
            return value;
        }
        if (body.TryGetProperty("status", out var status) && status.TryGetInt32(out var fallback))
        {
            return fallback;
        }
        return null;
    }

    private static Uri? RegionBase(JsonElement body)
    {
        if (!body.TryGetProperty("data", out var data) || data.ValueKind != JsonValueKind.Object)
        {
            return null;
        }

        string? candidate = null;
        if (data.TryGetProperty("domains", out var domains) &&
            domains.ValueKind == JsonValueKind.Object &&
            domains.TryGetProperty("api", out var api) &&
            api.ValueKind == JsonValueKind.String)
        {
            candidate = api.GetString();
        }

        foreach (var property in new[] { "domain", "host", "base_url" })
        {
            if (candidate is not null)
            {
                break;
            }
            if (data.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String)
            {
                candidate = value.GetString();
            }
        }

        if (string.IsNullOrWhiteSpace(candidate))
        {
            return null;
        }
        var url = candidate.StartsWith("http", StringComparison.OrdinalIgnoreCase)
            ? candidate
            : $"https://{candidate}";
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) ? uri : null;
    }
}
