using System.Text.Json;

namespace PlaudOnboarding;

public sealed record PlaudProvisionRequest
{
    public required string UserToken { get; init; }
    public required string Serial { get; init; }
    public string? BindToken { get; init; }
    public required string IdentityPath { get; init; }
    public Uri? BaseUri { get; init; }
}

public sealed record PlaudProvisionResult(
    string Serial,
    string BindToken,
    IReadOnlyList<string> Serials,
    PlaudIdentity Identity);

/// <summary>
/// One-time Plaud account onboarding.
///
/// Exchanges the <c>pld_ut</c> cookie of web.plaud.ai for the device identity
/// (per-serial SN signature + account-wide RSA-2048 key pair) and merges it into
/// an identity.json file. The token is used for this call only; the library
/// never stores or logs it.
///
/// The identity format matches plaud-summarizer and KOBY Translate.
/// </summary>
public sealed class PlaudOnboardingClient
{
    /// <summary>Fernet key embedded in the Plaud Android app (for encrypted responses).</summary>
    public const string AppFernetKey = "8rRmMCskL3NaUiGr-UsmEEeI8NKH-ZfeGbpRGqSLpuI=";

    public static readonly Uri DefaultBaseUri = new("https://api.plaud.ai");

    private readonly HttpClient _http;
    private readonly Uri _baseUri;

    /// <param name="httpClient">Optional client (proxy, custom handler, tests).</param>
    /// <param name="baseUri">Optional API override for a specific region.</param>
    public PlaudOnboardingClient(HttpClient? httpClient = null, Uri? baseUri = null)
    {
        _http = httpClient ?? new HttpClient { Timeout = TimeSpan.FromSeconds(60) };
        _baseUri = baseUri ?? DefaultBaseUri;
    }

    public Task<PlaudProvisionResult> ProvisionAsync(
        PlaudProvisionRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        return ProvisionAsync(
            request.UserToken,
            request.Serial,
            request.BindToken,
            request.IdentityPath,
            request.BaseUri,
            cancellationToken);
    }

    public async Task<PlaudProvisionResult> ProvisionAsync(
        string userToken,
        string serial,
        string? bindToken,
        string identityPath,
        Uri? baseUri = null,
        CancellationToken cancellationToken = default)
    {
        var token = PlaudToken.StripBearer(userToken);
        if (string.IsNullOrEmpty(token))
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.TokenRequired,
                "Plaud-Token fehlt (pld_ut-Cookie von web.plaud.ai).");
        }

        var normalizedSerial = serial.Trim().ToUpperInvariant();
        if (normalizedSerial.Length == 0)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.SerialRequired,
                "Seriennummer fehlt.");
        }

        var identity = PlaudIdentityStore.Load(identityPath) ?? new PlaudIdentity();

        string resolvedToken;
        if (!string.IsNullOrWhiteSpace(bindToken))
        {
            resolvedToken = PlaudToken.Normalize(bindToken);
        }
        else if (identity.Accounts.Count == 1)
        {
            resolvedToken = identity.Accounts.Keys.First();
        }
        else
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.BindTokenRequired,
                "Bind-Token erforderlich – er ist die Plaud-Benutzer-ID, nicht die Seriennummer.");
        }

        identity.Accounts.TryGetValue(resolvedToken, out var existing);

        var api = new PlaudApi(_http);
        var apiBase = baseUri ?? _baseUri;

        var signResponse = await api.PostAsync(
                "/device-app/device/sn-sign",
                new { sns = new[] { normalizedSerial } },
                token,
                apiBase,
                cancellationToken: cancellationToken)
            .ConfigureAwait(false);

        var signature = ReadSignature(signResponse.Body, normalizedSerial);

        // The RSA key pair is account-wide and reused across devices. Only
        // generate a new one when the identity has none yet.
        var privateKeyPem = existing?.PrivateKeyPem ?? string.Empty;
        var publicKeyPem = existing?.PublicKeyPem ?? string.Empty;
        if (string.IsNullOrEmpty(privateKeyPem))
        {
            var keyResponse = await api.PostAsync(
                    "/device-app/e2ee/gen_key",
                    new { },
                    token,
                    signResponse.BaseUri,
                    cancellationToken: cancellationToken)
                .ConfigureAwait(false);

            var (privatePem, publicPem) = ReadKeyPair(keyResponse.Body);
            privateKeyPem = privatePem;
            publicKeyPem = publicPem;
        }

        var now = DateTimeOffset.UtcNow.ToString("O");
        var account = existing ?? new PlaudAccount
        {
            BindToken = resolvedToken,
            Label = "Plaud-Konto",
            CreatedAt = now,
            UpdatedAt = now
        };
        account.BindToken = resolvedToken;
        account.PrivateKeyPem = privateKeyPem;
        account.PublicKeyPem = publicKeyPem;
        account.SnSignature[normalizedSerial] = signature;
        account.CreatedAt ??= now;
        account.UpdatedAt = now;
        identity.Accounts[resolvedToken] = account;

        PlaudIdentityStore.Save(identity, identityPath);

        return new PlaudProvisionResult(
            normalizedSerial,
            resolvedToken,
            identity.Serials,
            identity);
    }

    private static string ReadSignature(JsonElement body, string serial)
    {
        if (body.TryGetProperty("data", out var data) &&
            data.ValueKind == JsonValueKind.Object &&
            data.TryGetProperty("signature", out var signatures) &&
            signatures.ValueKind == JsonValueKind.Object &&
            signatures.TryGetProperty(serial, out var signature) &&
            signature.ValueKind == JsonValueKind.String)
        {
            var value = signature.GetString();
            if (!string.IsNullOrEmpty(value))
            {
                return value;
            }
        }

        throw new PlaudOnboardingException(
            PlaudErrorCode.InvalidResponse,
            $"Plaud-Antwort enthielt keine Signatur für {serial}.");
    }

    private static (string PrivatePem, string PublicPem) ReadKeyPair(JsonElement body)
    {
        if (body.TryGetProperty("data", out var data) &&
            data.ValueKind == JsonValueKind.Object &&
            data.TryGetProperty("private_key_base64", out var privateValue) &&
            privateValue.ValueKind == JsonValueKind.String &&
            data.TryGetProperty("public_key_base64", out var publicValue) &&
            publicValue.ValueKind == JsonValueKind.String)
        {
            try
            {
                var privatePem = System.Text.Encoding.UTF8.GetString(
                    Convert.FromBase64String(privateValue.GetString()!));
                var publicPem = System.Text.Encoding.UTF8.GetString(
                    Convert.FromBase64String(publicValue.GetString()!));
                return (privatePem, publicPem);
            }
            catch (FormatException)
            {
                // fall through to the shared error below
            }
        }

        throw new PlaudOnboardingException(
            PlaudErrorCode.InvalidResponse,
            "Plaud-Antwort enthielt kein Schlüsselpaar.");
    }
}
