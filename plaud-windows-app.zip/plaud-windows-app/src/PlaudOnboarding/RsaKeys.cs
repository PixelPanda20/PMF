using System.Security.Cryptography;

namespace PlaudOnboarding;

public sealed record PlaudKeyPair(string PrivateKeyPem, string PublicKeyPem);

internal static class RsaKeys
{
    /// <summary>
    /// Generates an RSA key pair in PEM form. .NET exports PKCS#1
    /// ("BEGIN RSA PRIVATE/PUBLIC KEY"), which Node and Python accept.
    /// </summary>
    public static PlaudKeyPair Generate(int bits = 2048)
    {
        try
        {
            using var rsa = RSA.Create(bits);
            return new PlaudKeyPair(
                EnsureTrailingNewline(rsa.ExportRSAPrivateKeyPem()),
                EnsureTrailingNewline(rsa.ExportRSAPublicKeyPem()));
        }
        catch (CryptographicException error)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.KeyGeneration,
                $"RSA-Schlüssel konnte nicht erzeugt werden: {error.Message}");
        }
    }

    private static string EnsureTrailingNewline(string pem)
    {
        return pem.EndsWith('\n') ? pem : pem + "\n";
    }
}
