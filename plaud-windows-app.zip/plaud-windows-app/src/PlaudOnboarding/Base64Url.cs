namespace PlaudOnboarding;

internal static class Base64Url
{
    /// <summary>Decodes standard or URL-safe base64, with or without padding.</summary>
    public static byte[] Decode(string value)
    {
        var normalized = value.Trim().Replace('-', '+').Replace('_', '/');
        switch (normalized.Length % 4)
        {
            case 2:
                normalized += "==";
                break;
            case 3:
                normalized += "=";
                break;
        }
        return Convert.FromBase64String(normalized);
    }

    /// <summary>URL-safe base64 without padding (Fernet's token encoding).</summary>
    public static string Encode(ReadOnlySpan<byte> value)
    {
        return Convert.ToBase64String(value)
            .TrimEnd('=')
            .Replace('+', '-')
            .Replace('/', '_');
    }
}

public static class PlaudToken
{
    /// <summary>The device handshake expects the bind token padded to 32 characters.</summary>
    public static string Normalize(string token)
    {
        var trimmed = token.Trim();
        var prefix = trimmed.Length > 32 ? trimmed[..32] : trimmed;
        return prefix.PadRight(32, '0');
    }

    public static string StripBearer(string token)
    {
        var trimmed = token.Trim();
        return trimmed.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? trimmed[7..].Trim()
            : trimmed;
    }
}
