using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlaudOnboarding.Tests")]
