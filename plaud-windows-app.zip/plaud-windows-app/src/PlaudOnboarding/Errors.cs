namespace PlaudOnboarding;

public enum PlaudErrorCode
{
    TokenRequired,
    SerialRequired,
    BindTokenRequired,
    InvalidToken,
    Api,
    ApiCode,
    InvalidResponse,
    Decryption,
    KeyGeneration,
    Storage
}

/// <summary>
/// Onboarding failure with a stable code and a user-facing message. Messages
/// never contain tokens or key material.
/// </summary>
public sealed class PlaudOnboardingException : Exception
{
    public PlaudErrorCode Code { get; }

    /// <summary>HTTP status when <see cref="Code"/> is <see cref="PlaudErrorCode.Api"/>.</summary>
    public int? HttpStatus { get; }

    public PlaudOnboardingException(PlaudErrorCode code, string message, int? httpStatus = null)
        : base(message)
    {
        Code = code;
        HttpStatus = httpStatus;
    }
}
