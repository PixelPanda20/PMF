using System.Text.Json;
using System.Text.Json.Serialization;

namespace PlaudOnboarding;

/// <summary>One Plaud account inside the identity file (v2 format).</summary>
public sealed class PlaudAccount
{
    [JsonPropertyName("bind_token")]
    public string BindToken { get; set; } = string.Empty;

    [JsonPropertyName("label")]
    public string? Label { get; set; }

    [JsonPropertyName("private_key_pem")]
    public string PrivateKeyPem { get; set; } = string.Empty;

    [JsonPropertyName("public_key_pem")]
    public string PublicKeyPem { get; set; } = string.Empty;

    [JsonPropertyName("sn_signature")]
    public Dictionary<string, string> SnSignature { get; set; } = new();

    [JsonPropertyName("created_at")]
    public string? CreatedAt { get; set; }

    [JsonPropertyName("updated_at")]
    public string? UpdatedAt { get; set; }
}

/// <summary>
/// The identity file shared with plaud-summarizer and KOBY Translate:
/// <c>{ "version": 2, "accounts": { "&lt;bind_token&gt;": { ... } } }</c>.
/// </summary>
public sealed class PlaudIdentity
{
    [JsonPropertyName("version")]
    public int Version { get; set; } = 2;

    [JsonPropertyName("accounts")]
    public Dictionary<string, PlaudAccount> Accounts { get; set; } = new();

    /// <summary>Serial numbers with a signature, excluding the wildcard entry.</summary>
    [JsonIgnore]
    public IReadOnlyList<string> Serials =>
        Accounts.Values
            .SelectMany(account => account.SnSignature.Keys)
            .Where(serial => serial != "*")
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(serial => serial, StringComparer.OrdinalIgnoreCase)
            .ToList();
}

public static class PlaudIdentityStore
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    /// <summary>Loads v2 files and migrates the old flat v1 account.</summary>
    public static PlaudIdentity? Load(string path)
    {
        if (!File.Exists(path))
        {
            return null;
        }

        try
        {
            var json = File.ReadAllText(path);
            using var document = JsonDocument.Parse(json);
            var root = document.RootElement;

            if (root.ValueKind == JsonValueKind.Object &&
                root.TryGetProperty("accounts", out _))
            {
                return JsonSerializer.Deserialize<PlaudIdentity>(json, Options)
                    ?? throw new PlaudOnboardingException(
                        PlaudErrorCode.Storage,
                        "Identitätsdatei konnte nicht gelesen werden.");
            }

            if (root.ValueKind == JsonValueKind.Object &&
                root.TryGetProperty("private_key_pem", out _))
            {
                var account = JsonSerializer.Deserialize<PlaudAccount>(json, Options)
                    ?? throw new PlaudOnboardingException(
                        PlaudErrorCode.Storage,
                        "Identitätsdatei konnte nicht gelesen werden.");
                var token = PlaudToken.Normalize(account.BindToken);
                return new PlaudIdentity
                {
                    Accounts = new Dictionary<string, PlaudAccount> { [token] = account }
                };
            }
        }
        catch (JsonException error)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.Storage,
                $"Identitätsdatei ist kein gültiges JSON: {error.Message}");
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.Storage,
                $"Identitätsdatei nicht lesbar: {error.Message}");
        }

        throw new PlaudOnboardingException(
            PlaudErrorCode.Storage,
            "Format der Identitätsdatei ist unbekannt.");
    }

    /// <summary>Writes atomically (temp file + move) and creates the directory.</summary>
    public static void Save(PlaudIdentity identity, string path)
    {
        try
        {
            var directory = Path.GetDirectoryName(Path.GetFullPath(path));
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            var json = JsonSerializer.Serialize(identity, Options);
            var temp = path + "." + Environment.ProcessId + ".tmp";
            File.WriteAllText(temp, json);
            File.Move(temp, path, overwrite: true);

            // Best effort on Windows: the file lives in %LOCALAPPDATA%, which is
            // per-user; ntfs ACLs inherit from that folder.
            if (!OperatingSystem.IsWindows())
            {
                File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
            }
        }
        catch (PlaudOnboardingException)
        {
            throw;
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException)
        {
            throw new PlaudOnboardingException(
                PlaudErrorCode.Storage,
                $"Identität konnte nicht gespeichert werden: {error.Message}");
        }
    }
}
