using Plaud.Core;
using Xunit;

namespace Plaud.Tests;

public class PlaudStoreTests : IDisposable
{
    private readonly string _directory = Path.Combine(
        Path.GetTempPath(), "plaud-store-" + Guid.NewGuid().ToString("N"));
    private readonly PlaudStore _store;
    private readonly AudioStore _audio;

    public PlaudStoreTests()
    {
        Directory.CreateDirectory(_directory);
        _store = new PlaudStore(Path.Combine(_directory, "plaud.db"));
        _store.Initialize();
        _audio = new AudioStore(Path.Combine(_directory, "audio"));
    }

    public void Dispose()
    {
        if (Directory.Exists(_directory))
        {
            Directory.Delete(_directory, recursive: true);
        }
    }

    [Fact]
    public void InsertsAndReadsRecording()
    {
        var recording = new Recording
        {
            Title = "Test",
            AudioPath = "/tmp/a.ogg",
            Transcript = "Hallo Welt",
            Status = RecordingStatus.Transcribed
        };
        _store.Insert(recording);

        var loaded = _store.Get(recording.Id);
        Assert.NotNull(loaded);
        Assert.Equal("Hallo Welt", loaded!.Transcript);
        Assert.Equal(RecordingStatus.Transcribed, loaded.Status);
    }

    [Fact]
    public void SearchesTitleTranscriptAndSummary()
    {
        _store.Insert(new Recording { Title = "Sitzung", Transcript = "Projekt Atlas" });
        _store.Insert(new Recording { Title = "Interview", Transcript = "etwas anderes" });

        Assert.Single(_store.List("Atlas"));
        Assert.Single(_store.List("Interview"));
        Assert.Empty(_store.List("nicht vorhanden"));
    }

    [Fact]
    public void StoresAndFiltersTags()
    {
        var recording = new Recording { Title = "Mit Tag", AudioPath = "/tmp/a.ogg" };
        _store.Insert(recording);
        _store.SetTags(recording.Id, new[] { "projekt", "wichtig", "projekt" });

        var loaded = _store.Get(recording.Id)!;
        Assert.Equal(new[] { "projekt", "wichtig" }, loaded.Tags.OrderBy(tag => tag));
        Assert.Single(_store.List(tag: "projekt"));
        Assert.Equal(new[] { "projekt", "wichtig" }, _store.ListTags());
    }

    [Fact]
    public void SettingsRoundTrip()
    {
        _store.SetSetting("bitai.baseUrl", "https://example/v1");
        Assert.Equal("https://example/v1", _store.GetSetting("bitai.baseUrl"));
        _store.SetSetting("bitai.baseUrl", "https://other/v1");
        Assert.Equal("https://other/v1", _store.GetSetting("bitai.baseUrl"));
        Assert.Null(_store.GetSetting("missing"));
    }

    [Fact]
    public void DeletesRecordingAndTags()
    {
        var recording = new Recording { Title = "Weg", AudioPath = "/tmp/a.ogg" };
        _store.Insert(recording);
        _store.SetTags(recording.Id, new[] { "x" });
        _store.Delete(recording.Id);

        Assert.Null(_store.Get(recording.Id));
        Assert.Empty(_store.ListTags());
    }
}

public class RecordingServiceTests : IDisposable
{
    private readonly string _directory = Path.Combine(
        Path.GetTempPath(), "plaud-service-" + Guid.NewGuid().ToString("N"));
    private readonly PlaudStore _store;
    private readonly AudioStore _audio;

    public RecordingServiceTests()
    {
        Directory.CreateDirectory(_directory);
        _store = new PlaudStore(Path.Combine(_directory, "plaud.db"));
        _store.Initialize();
        _audio = new AudioStore(Path.Combine(_directory, "audio"));
    }

    public void Dispose()
    {
        if (Directory.Exists(_directory))
        {
            Directory.Delete(_directory, recursive: true);
        }
    }

    [Fact]
    public async Task ImportsTranscribesAndSummarizes()
    {
        var transcriber = new FakeTranscriber();
        var summarizer = new FakeSummarizer();
        var service = new RecordingService(_store, _audio, transcriber, summarizer);

        using var audio = new MemoryStream(new byte[] { 1, 2, 3 });
        var recording = await service.ImportAsync(audio, "Besprechung", ".ogg");
        Assert.True(File.Exists(recording.AudioPath));

        var transcribed = await service.TranscribeAsync(recording.Id);
        Assert.Equal("Hallo aus dem Test", transcribed.Transcript);
        Assert.Equal(RecordingStatus.Transcribed, transcribed.Status);
        Assert.Equal("de", transcribed.TranscriptLanguage);

        var summarized = await service.SummarizeAsync(recording.Id, "interview");
        Assert.Equal("{\"summary\":\"ok\"}", summarized.SummaryJson);
        Assert.Equal(RecordingStatus.Ready, summarized.Status);
        Assert.Equal("interview", summarized.TemplateId);

        var answer = await service.AskAsync(recording.Id, "Worum geht es?");
        Assert.Equal("Antwort", answer);
    }

    [Fact]
    public async Task MarksRecordingAsErrorWhenTranscriptionFails()
    {
        var service = new RecordingService(
            _store,
            _audio,
            new FakeTranscriber { Fail = true },
            new FakeSummarizer());

        using var audio = new MemoryStream(new byte[] { 1 });
        var recording = await service.ImportAsync(audio, "Fehler");

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => service.TranscribeAsync(recording.Id));

        var loaded = _store.Get(recording.Id)!;
        Assert.Equal(RecordingStatus.Error, loaded.Status);
        Assert.Contains("kaputt", loaded.Error);
    }

    [Fact]
    public async Task SummarizeRequiresTranscript()
    {
        var service = new RecordingService(_store, _audio, new FakeTranscriber(), new FakeSummarizer());
        using var audio = new MemoryStream(new byte[] { 1 });
        var recording = await service.ImportAsync(audio, "Ohne Transkript");

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => service.SummarizeAsync(recording.Id));
    }

    [Fact]
    public async Task DeleteRemovesAudioAndRow()
    {
        var service = new RecordingService(_store, _audio, new FakeTranscriber(), new FakeSummarizer());
        using var audio = new MemoryStream(new byte[] { 1 });
        var recording = await service.ImportAsync(audio, "Weg");

        service.Delete(recording.Id);

        Assert.Null(_store.Get(recording.Id));
        Assert.False(File.Exists(recording.AudioPath));
    }

    private sealed class FakeTranscriber : ITranscriber
    {
        public bool Fail { get; init; }

        public Task<TranscriptResult> TranscribeAsync(
            Stream audio,
            string fileName,
            string? language,
            CancellationToken cancellationToken = default)
        {
            if (Fail)
            {
                throw new InvalidOperationException("Mikrofon kaputt");
            }
            return Task.FromResult(
                new TranscriptResult(
                    "Hallo aus dem Test",
                    "de",
                    12.5,
                    new[] { new TranscriptSegment(0, 12.5, "Hallo aus dem Test") }));
        }
    }

    private sealed class FakeSummarizer : ISummarizer
    {
        public Task<string> SummarizeAsync(
            string transcript,
            string templateId,
            CancellationToken cancellationToken = default) =>
            Task.FromResult("{\"summary\":\"ok\"}");

        public Task<string> AskAsync(
            string question,
            string transcript,
            string? summaryJson,
            CancellationToken cancellationToken = default) =>
            Task.FromResult("Antwort");
    }
}
