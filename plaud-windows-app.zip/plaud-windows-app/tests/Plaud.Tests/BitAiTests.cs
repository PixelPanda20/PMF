using System.Net;
using System.Text;
using System.Text.Json;
using Plaud.BitAi;
using Xunit;

namespace Plaud.Tests;

public class BitAiClientTests
{
    private const string BaseUrl = "https://bitai.test/v1";

    [Fact]
    public async Task TranscribesWithVerboseJson()
    {
        HttpRequestMessage? captured = null;
        string? body = null;
        var handler = new StubHandler(async request =>
        {
            captured = request;
            body = await request.Content!.ReadAsStringAsync();
            return Json(
                """
                {"text":"Hallo Welt","language":"de","duration":2.5,
                 "segments":[{"start":0,"end":2.5,"text":"Hallo Welt"}]}
                """);
        });

        using var http = new HttpClient(handler);
        var client = new BitAiClient(http, Options());
        using var audio = new MemoryStream(new byte[] { 1, 2, 3 });

        var result = await client.TranscribeAsync(audio, "note.ogg", "de");

        Assert.Equal("Hallo Welt", result.Text);
        Assert.Equal("de", result.Language);
        Assert.Equal(2.5, result.Duration);
        Assert.Single(result.Segments);
        Assert.Equal($"{BaseUrl}/audio/transcriptions", captured!.RequestUri!.ToString());
        Assert.Equal("Bearer test-key", captured.Headers.Authorization!.ToString());
        Assert.Contains("name=model", body);
        Assert.Contains("whisper-test", body);
        Assert.Contains("verbose_json", body);
        Assert.Contains("name=file", body);
    }

    [Fact]
    public async Task SummarizesAndSendsTemplateFocus()
    {
        string? body = null;
        var handler = new StubHandler(async request =>
        {
            body = await request.Content!.ReadAsStringAsync();
            return Json(
                """
                {"choices":[{"message":{"content":"{\"summary\":\"ok\"}"}}]}
                """);
        });

        using var http = new HttpClient(handler);
        var client = new BitAiClient(http, Options());

        var result = await client.SummarizeAsync("Transkript", "interview");

        Assert.Contains("summary", result);
        Assert.Contains("Kernaussagen", body);
        Assert.Contains("Transkript", body);
    }

    [Fact]
    public async Task SplitsLongTranscriptsIntoNotes()
    {
        var calls = 0;
        var handler = new StubHandler(async request =>
        {
            calls++;
            var body = await request.Content!.ReadAsStringAsync();
            return body.Contains("Protokoll-Assistent", StringComparison.Ordinal)
                ? Json("""{"choices":[{"message":{"content":"{\"summary\":\"final\"}"}}]}""")
                : Json("""{"choices":[{"message":{"content":"{\"notes\":[\"Punkt 1\"]}"}}]}""");
        });

        using var http = new HttpClient(handler);
        var client = new BitAiClient(http, Options());
        var longText = string.Join(" ", Enumerable.Repeat("Ein langer Satz.", 3000));

        var result = await client.SummarizeAsync(longText, "standard");

        Assert.True(calls >= 2);
        Assert.Contains("final", result);
    }

    [Fact]
    public async Task AnswersQuestions()
    {
        var handler = new StubHandler(async _ =>
            Json("""{"choices":[{"message":{"content":"Die Antwort."}}]}"""));

        using var http = new HttpClient(handler);
        var client = new BitAiClient(http, Options());

        var answer = await client.AskAsync("Frage?", "Transkript", null);

        Assert.Equal("Die Antwort.", answer);
    }

    [Fact]
    public async Task MapsHttpErrors()
    {
        var handler = new StubHandler(_ =>
            Task.FromResult(new HttpResponseMessage(HttpStatusCode.Unauthorized)));
        using var http = new HttpClient(handler);
        var client = new BitAiClient(http, Options());

        var error = await Assert.ThrowsAsync<BitAiException>(
            () => client.SummarizeAsync("Text", "standard"));
        Assert.Equal(401, error.HttpStatus);
    }

    [Fact]
    public async Task RejectsUnconfiguredBaseUrl()
    {
        var client = new BitAiClient(new HttpClient(), new BitAiOptions());
        await Assert.ThrowsAsync<BitAiException>(
            () => client.SummarizeAsync("Text", "standard"));
    }

    private static BitAiOptions Options() =>
        new()
        {
            BaseUrl = BaseUrl,
            ApiKey = "test-key",
            SttModel = "whisper-test",
            ChatModel = "chat-test"
        };

    private static HttpResponseMessage Json(string body) =>
        new(HttpStatusCode.OK)
        {
            Content = new StringContent(body, Encoding.UTF8, "application/json")
        };

    private sealed class StubHandler : HttpMessageHandler
    {
        private readonly Func<HttpRequestMessage, Task<HttpResponseMessage>> _respond;

        public StubHandler(Func<HttpRequestMessage, Task<HttpResponseMessage>> respond)
        {
            _respond = respond;
        }

        protected override Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken) =>
            _respond(request);
    }
}
