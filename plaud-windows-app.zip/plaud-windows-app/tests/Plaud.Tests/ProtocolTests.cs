using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using Plaud.Ble.Protocol;
using Xunit;

namespace Plaud.Tests;

public class ChaCha20Tests
{
    [Fact]
    public void MatchesRfc8439KeystreamVector()
    {
        var key = Enumerable.Range(0, 32).Select(value => (byte)value).ToArray();
        var nonce = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0x4a, 0, 0, 0, 0 };
        var plaintext = Encoding.ASCII.GetBytes(
            "Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it.");

        var ciphertext = ChaCha20.Transform(key, nonce, 1, plaintext);

        var expected =
            "6e2e359a2568f98041ba0728dd0d6981e97e7aec1d4360c20a27afccfd9fae0b" +
            "f91b65c5524733ab8f593dabcd62b3571639d624e65152ab8f530c359f0861d8" +
            "07ca0dbf500d6a6156a38e088a22b65e52bc514d16ccf806818ce91ab7793736" +
            "5af90bbf74a35be6b40b8eedf2785e42874d";
        Assert.Equal(expected, Convert.ToHexString(ciphertext).ToLowerInvariant());
    }
}

public class SessionCipherTests
{
    [Fact]
    public void EncryptsAndDecryptsWithMonotonicSequence()
    {
        var key = Enumerable.Range(0, 32).Select(value => (byte)value).ToArray();
        var nonce = Enumerable.Range(0, 12).Select(value => (byte)value).ToArray();
        var aad = Enumerable.Range(0, 12).Select(value => (byte)(0x40 + value)).ToArray();

        var sender = new SessionCipher(key, nonce, aad);
        var receiver = new SessionCipher(key, nonce, aad);
        var packet = new byte[] { 1, 26, 0, 42 };

        var sealedPacket = sender.Encrypt(packet);
        Assert.Equal(packet, receiver.Decrypt(sealedPacket));

        Assert.Throws<ProtocolException>(() => receiver.Decrypt(sealedPacket));
    }
}

public class OggTests
{
    [Fact]
    public void WrapsFramesAndVerifiesCrc()
    {
        var frames = Enumerable.Range(0, 120)
            .Select(_ => Enumerable.Repeat((byte)0xf8, 80).ToArray())
            .ToList();

        var ogg = Ogg.WriteOggOpus(frames);

        Assert.True(Ogg.VerifyOgg(ogg));
        Assert.Equal(4, Ogg.FramesFromRaw(new byte[320], 1).Count);

        var broken = (byte[])ogg.Clone();
        broken[^5] ^= 0xff;
        Assert.False(Ogg.VerifyOgg(broken));
    }
}

public class PacketTests
{
    [Fact]
    public void BuildsHandshakeWithPaddedToken()
    {
        var packet = PlaudProtocol.HandshakePacket("user-1", 20);
        Assert.Equal(1, packet[0]);
        Assert.Equal(PlaudProtocol.CmdHandshake, PlaudProtocol.ReadU16(packet, 1));
        Assert.Equal(3 + 3 + 32, packet.Length);
        Assert.Equal("user-1" + new string('0', 26), Encoding.ASCII.GetString(packet, 6, 32));
    }

    [Fact]
    public void ParsesHandshakeResponse()
    {
        var packet = new byte[12];
        packet[0] = 1;
        BinaryPrimitives.WriteUInt16LittleEndian(packet.AsSpan(1), PlaudProtocol.CmdHandshake);
        packet[3] = 0;
        BinaryPrimitives.WriteUInt16LittleEndian(packet.AsSpan(4), 20);
        packet[8] = 1;
        packet[11] = 1;

        var parsed = PlaudProtocol.ParseHandshake(packet);
        Assert.Equal(20, parsed.PortVersion);
        Assert.Equal(1, parsed.Channels);
        Assert.True(parsed.OggAudio);
    }

    [Fact]
    public void ParsesSessionList()
    {
        var packet = new byte[11 + 20];
        packet[0] = 1;
        BinaryPrimitives.WriteUInt16LittleEndian(packet.AsSpan(1), PlaudProtocol.CmdGetRecSessions);
        BinaryPrimitives.WriteUInt16LittleEndian(packet.AsSpan(7), 2);
        BinaryPrimitives.WriteUInt32LittleEndian(packet.AsSpan(11), 100);
        BinaryPrimitives.WriteUInt32LittleEndian(packet.AsSpan(15), 4096);
        BinaryPrimitives.WriteUInt32LittleEndian(packet.AsSpan(21), 200);
        BinaryPrimitives.WriteUInt32LittleEndian(packet.AsSpan(25), 8192);

        var parsed = PlaudProtocol.ParseSessionList(packet, 20);
        Assert.Equal(2, parsed.Total);
        Assert.Equal(2, parsed.Entries.Count);
        Assert.Equal(4096u, parsed.Entries[0].Size);
    }

    [Fact]
    public void ParsesDataPacket()
    {
        var packet = new byte[10 + 3];
        packet[0] = 2;
        BinaryPrimitives.WriteUInt32LittleEndian(packet.AsSpan(1), 100);
        BinaryPrimitives.WriteUInt32LittleEndian(packet.AsSpan(5), 40);
        packet[9] = 3;
        packet[10] = 0xaa;
        packet[11] = 0xbb;
        packet[12] = 0xcc;

        var parsed = PlaudProtocol.ParseDataPacket(packet, 20, 100);
        Assert.NotNull(parsed);
        Assert.Equal(40u, parsed!.Offset);
        Assert.Equal(new byte[] { 0xaa, 0xbb, 0xcc }, parsed.Chunk);

        Assert.Null(PlaudProtocol.ParseDataPacket(packet, 20, 999));
    }
}

public class IdentityUnlockTests
{
    [Fact]
    public void DecryptsSessionSecret()
    {
        using var rsa = RSA.Create(2048);
        var pem = rsa.ExportRSAPrivateKeyPem();
        var key = RandomNumberGenerator.GetBytes(32);
        var nonce = RandomNumberGenerator.GetBytes(12);
        var aad = RandomNumberGenerator.GetBytes(12);

        var check = Encoding.ASCII.GetBytes("PLAUD.AI");
        var ciphertext = new byte[check.Length];
        var tag = new byte[16];
        using (var aead = new ChaCha20Poly1305(key))
        {
            aead.Encrypt(nonce, check, ciphertext, tag, aad);
        }

        var payload = new byte[32 + 12 + 12 + ciphertext.Length + 16];
        key.CopyTo(payload, 0);
        nonce.CopyTo(payload, 32);
        aad.CopyTo(payload, 44);
        ciphertext.CopyTo(payload, 56);
        tag.CopyTo(payload, 56 + ciphertext.Length);

        var secret = rsa.Encrypt(payload, RSAEncryptionPadding.Pkcs1);
        var keys = IdentityUnlock.DecryptSessionSecret(pem, secret);

        Assert.Equal(key, keys.Key);
        Assert.Equal(nonce, keys.Nonce);
        Assert.Equal(aad, keys.AssociatedData);
    }

    [Fact]
    public void DecryptsPlaudFile()
    {
        using var rsa = RSA.Create(2048);
        var pem = rsa.ExportRSAPrivateKeyPem();
        var contentKey = RandomNumberGenerator.GetBytes(32);
        var nonce = RandomNumberGenerator.GetBytes(12);
        const uint counter = 7;
        var plaintext = Encoding.ASCII.GetBytes("OggS-test-audio-content");

        var header = new byte[512];
        Encoding.ASCII.GetBytes("PLAUD.AI").CopyTo(header, 0);
        BinaryPrimitives.WriteUInt16LittleEndian(header.AsSpan(8), 1);
        BinaryPrimitives.WriteUInt16LittleEndian(header.AsSpan(10), 512);
        BinaryPrimitives.WriteUInt32LittleEndian(header.AsSpan(128), counter);
        nonce.CopyTo(header, 132);
        rsa.Encrypt(contentKey, RSAEncryptionPadding.Pkcs1).CopyTo(header, 256);

        var ciphertext = ChaCha20.Transform(contentKey, nonce, counter, plaintext);
        var file = header.Concat(ciphertext).ToArray();

        var decrypted = IdentityUnlock.DecryptPlaudFile(pem, file);
        Assert.Equal(plaintext, decrypted);
    }
}

public class TransferAssemblerTests
{
    [Fact]
    public void SkipsDuplicatesAndFlagsGaps()
    {
        var assembler = new TransferAssembler();
        Assert.True(assembler.Add(0, new byte[] { 1, 2 }));
        Assert.False(assembler.Add(0, new byte[] { 1, 2 }));
        Assert.True(assembler.Add(2, new byte[] { 3 }));

        var gap = Assert.Throws<TransferGapException>(
            () => assembler.Add(10, new byte[] { 9 }));
        Assert.Equal(3u, gap.Expected);
        Assert.NotEmpty(gap.Message);
    }

    [Fact]
    public void ConcatenatesChunks()
    {
        var assembler = new TransferAssembler();
        assembler.Add(0, new byte[] { 1, 2 });
        assembler.Add(2, new byte[] { 3 });
        Assert.Equal(new byte[] { 1, 2, 3 }, assembler.ToArray());
    }
}
