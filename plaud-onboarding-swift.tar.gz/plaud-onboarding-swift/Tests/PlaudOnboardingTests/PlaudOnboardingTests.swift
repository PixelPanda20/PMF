import Foundation
import XCTest

@testable import PlaudOnboarding

final class FernetTests: XCTestCase {
    /// Generated with the app Fernet key and a fixed IV (see docs/README).
    private let token =
        "gAAAAAAAAAAAEREREREREREREREREREREebLJlEWpswCPvBp71fnOBrXUqxkwkCZSKB3jqubwKexHTZGmZkI12REIHmZ7uU3Mi4_0Jn3ZU6pC1B5ubZI1n1zezgmHJ_HGQfb8t0thMCGbMDYTSVSu-L6-SUexzHZm2fnfEPbBVo9Vr1bwLucFS4"

    func testDecryptsEncryptedPlaudResponse() throws {
        let data = try Fernet.decrypt(token, key: PlaudOnboardingClient.appFernetKey)
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        let payload = json?["data"] as? [String: Any]
        let signatures = payload?["signature"] as? [String: String]
        XCTAssertEqual(signatures?["8810B50336581126"], "sig-test-123")
    }

    func testRejectsTamperedToken() throws {
        var raw = try XCTUnwrap(Data(base64URLEncoded: token))
        raw[raw.count - 1] ^= 0xff
        XCTAssertThrowsError(
            try Fernet.decrypt(raw.base64URLEncodedString(), key: PlaudOnboardingClient.appFernetKey)
        )
    }

    func testRejectsWrongKey() {
        XCTAssertThrowsError(
            try Fernet.decrypt(token, key: Data(repeating: 0, count: 32).base64URLEncodedString())
        )
    }
}

final class TokenTests: XCTestCase {
    func testNormalizesTo32Characters() {
        XCTAssertEqual(PlaudToken.normalize("abc"), "abc".padding(toLength: 32, withPad: "0", startingAt: 0))
        XCTAssertEqual(PlaudToken.normalize(String(repeating: "x", count: 40)).count, 32)
    }

    func testStripsBearerPrefix() {
        XCTAssertEqual(PlaudToken.stripBearer("Bearer pld_ut_123"), "pld_ut_123")
        XCTAssertEqual(PlaudToken.stripBearer("pld_ut_123"), "pld_ut_123")
    }
}

final class IdentityStoreTests: XCTestCase {
    private var directory: URL!

    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }

    override func tearDownWithError() throws {
        try? FileManager.default.removeItem(at: directory)
    }

    func testRoundTripAndPermissions() throws {
        let url = directory.appendingPathComponent("identity.json")
        let account = PlaudAccount(
            bindToken: PlaudToken.normalize("user-1"),
            privateKeyPem: "PRIVATE",
            publicKeyPem: "PUBLIC",
            snSignature: ["SERIAL1": "sig"]
        )
        let identity = PlaudIdentity(accounts: [account.bindToken: account])

        try PlaudIdentityStore.save(identity, to: url)
        let loaded = try XCTUnwrap(PlaudIdentityStore.load(from: url))
        XCTAssertEqual(loaded.serials, ["SERIAL1"])
        XCTAssertEqual(loaded.accounts[account.bindToken]?.privateKeyPem, "PRIVATE")

        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        let permissions = attributes[.posixPermissions] as? NSNumber
        XCTAssertEqual(permissions?.intValue, 0o600)
    }

    func testMigratesFlatV1File() throws {
        let url = directory.appendingPathComponent("identity.json")
        let v1: [String: Any] = [
            "bind_token": "user-1",
            "private_key_pem": "PRIVATE",
            "public_key_pem": "PUBLIC",
            "sn_signature": ["SERIAL1": "sig"]
        ]
        let data = try JSONSerialization.data(withJSONObject: v1)
        try data.write(to: url)

        let loaded = try XCTUnwrap(PlaudIdentityStore.load(from: url))
        XCTAssertEqual(loaded.version, 2)
        XCTAssertEqual(loaded.accounts.count, 1)
        XCTAssertEqual(loaded.accounts[PlaudToken.normalize("user-1")]?.snSignature["SERIAL1"], "sig")
    }

    func testUnknownFormatThrows() throws {
        let url = directory.appendingPathComponent("identity.json")
        try Data("not json".utf8).write(to: url)
        XCTAssertThrowsError(try PlaudIdentityStore.load(from: url))
    }
}

#if canImport(Security)
final class RSAKeyPairTests: XCTestCase {
    func testGeneratesPemKeyPair() throws {
        let pair = try RSAKeyPair.generate()
        XCTAssertTrue(pair.privateKeyPEM.hasPrefix("-----BEGIN RSA PRIVATE KEY-----"))
        XCTAssertTrue(pair.privateKeyPEM.hasSuffix("-----END RSA PRIVATE KEY-----\n"))
        XCTAssertTrue(pair.publicKeyPEM.hasPrefix("-----BEGIN RSA PUBLIC KEY-----"))
    }
}
#endif
