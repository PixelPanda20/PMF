# PlaudOnboarding (Swift Package)

One-time Plaud account onboarding for a native macOS app: exchange the
`pld_ut` cookie of `web.plaud.ai` for the device identity and write a
`identity.json` that the recorder accepts.

The package is the Swift port of the provisioning logic in
`koby-translate-work/server/plaud/identity.js` and
`plaud-summarizer/backend/app/ble/identity_fetch.py`:

- `POST https://api.plaud.ai/device-app/device/sn-sign` → per-serial SN signature
- `POST https://api.plaud.ai/device-app/e2ee/gen_key` → RSA-2048 key pair
  (only when the identity has no key yet; the pair is account-wide)
- Fernet-decrypts responses flagged with `X-Encrypt-Response: 1`
- follows the API's region redirect (`code == -302`)
- merges into the v2 identity format used by `plaud-summarizer`/KOBY

## Requirements

- macOS 12+
- Swift 5.9 / Xcode 15+
- App Sandbox: outgoing network access (`com.apple.security.network.client`) if
  the app is sandboxed

> **Not compiled here:** this workspace is Linux and has no Swift toolchain.
> The code follows the tested Node implementation, and the Fernet test vector
> was generated from it, but run `swift test` on macOS before shipping.

## Add to the app

In Xcode: *File → Add Package Dependencies… → Add Local…* and select this
folder, or in `Package.swift`:

```swift
.package(path: "../PlaudOnboarding")
```

## Usage

```swift
import PlaudOnboarding

let identityURL = FileManager.default
    .urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
    .appendingPathComponent("MyMacApp/identity.json")

let result = try await PlaudOnboardingClient().provision(
    userToken: pldUtCookie,          // from web.plaud.ai → DevTools → Cookies
    serial: "8810B50336581126",
    bindToken: plaudUserId,          // required for a new account
    identityURL: identityURL
)

print(result.serials)                // e.g. ["8810B50336581126"]
```

The token is used for this call only. The library does not persist it, does not
log it, and never writes it into the identity file.

`bindToken` is the Plaud user id (the reference app calls it `bind_token`). If
the identity file already contains exactly one account, it can be omitted. For a
fresh install it is required — do not use the serial number.

## Identity file

```json
{
  "version": 2,
  "accounts": {
    "<bind_token>": {
      "bind_token": "<bind_token>",
      "label": "Plaud-Konto",
      "private_key_pem": "-----BEGIN RSA PRIVATE KEY-----…",
      "public_key_pem": "-----BEGIN RSA PUBLIC KEY-----…",
      "sn_signature": { "8810B50336581126": "…" },
      "created_at": "…",
      "updated_at": "…"
    }
  }
}
```

Written atomically with POSIX mode `0600`. Store it in Application Support,
never in UserDefaults or the app bundle. Consider Keychain for the private key
if the threat model requires it.

## Security notes

- Treat `identity.json` like a private key: it unlocks the device's recordings.
- Do not put the `pld_ut` token into logs, analytics, crash reports or the
  Keychain permanently; it expires and is only needed once.
- Delete the token from memory after `provision` returns.
- Verify the TLS connection normally (URLSession default); no certificate
  pinning is implemented.
- If the API answers `401`, the cookie expired — ask the user to copy a fresh
  one from `web.plaud.ai`.

## CLI

```bash
swift run plaud-onboard \
  --token "$PLD_UT" \
  --serial 8810B50336581126 \
  --bind "$PLAUD_USER_ID" \
  --out "$HOME/Library/Application Support/MyMacApp/identity.json"
```

## Tests

```bash
swift test
```

Covers Fernet decryption (static vector), token normalization, identity
round-trip/v1 migration, `0600` permissions and RSA PEM generation.

## Manual verification on macOS

1. Get a valid `pld_ut` from `web.plaud.ai` and the Plaud user id.
2. Run the CLI with a temporary output path.
3. Check that the file contains `version: 2`, exactly one account with your
   bind token, an SN signature for the serial and an RSA key pair.
4. Check permissions: `stat -f "%Lp" identity.json` → `600`.
5. Feed the file to the recorder app / KOBY (`PLAUDE_IDENTITY_FILE`) and
   connect once. Re-running onboarding for a second device reuses the key pair
   and only adds the signature.
