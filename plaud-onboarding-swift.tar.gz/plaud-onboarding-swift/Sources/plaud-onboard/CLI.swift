import Darwin
import Foundation
import PlaudOnboarding

/// Minimal command-line smoke test for the onboarding package.
///
///   plaud-onboard --token <pld_ut> --serial <sn> --bind <bind-token> \
///                 --out ~/Library/Application\ Support/MyApp/identity.json
@main
struct PlaudOnboardCLI {
    static func main() async {
        var values: [String: String] = [:]
        var iterator = CommandLine.arguments.dropFirst().makeIterator()
        while let argument = iterator.next() {
            guard argument.hasPrefix("--"), let value = iterator.next() else { continue }
            values[String(argument.dropFirst(2))] = value
        }

        guard let token = values["token"], let serial = values["serial"] else {
            let usage =
                "usage: plaud-onboard --token <pld_ut> --serial <sn> "
                + "[--bind <bind-token>] --out <identity.json> [--base <url>]\n"
            FileHandle.standardError.write(Data(usage.utf8))
            exit(2)
        }

        let output = URL(
            fileURLWithPath: values["out"]
                ?? FileManager.default.currentDirectoryPath + "/identity.json"
        )
        let base = values["base"].flatMap(URL.init(string:))

        do {
            let result = try await PlaudOnboardingClient().provision(
                userToken: token,
                serial: serial,
                bindToken: values["bind"],
                identityURL: output,
                baseURL: base
            )
            print("identity written: \(output.path)")
            print("serial: \(result.serial)")
            print("serials: \(result.serials.joined(separator: ", "))")
        } catch {
            FileHandle.standardError.write(Data("error: \(error.localizedDescription)\n".utf8))
            exit(1)
        }
    }
}
