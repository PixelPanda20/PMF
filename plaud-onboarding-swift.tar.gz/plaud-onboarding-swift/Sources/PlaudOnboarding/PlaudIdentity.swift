import Foundation

/// One Plaud account inside the identity file (v2 format, compatible with
/// `plaud-summarizer` and KOBY Translate).
public struct PlaudAccount: Codable, Sendable {
    public var bindToken: String
    public var label: String?
    public var privateKeyPem: String
    public var publicKeyPem: String
    public var snSignature: [String: String]
    public var createdAt: String?
    public var updatedAt: String?

    enum CodingKeys: String, CodingKey {
        case bindToken = "bind_token"
        case label
        case privateKeyPem = "private_key_pem"
        case publicKeyPem = "public_key_pem"
        case snSignature = "sn_signature"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }

    public init(
        bindToken: String,
        label: String? = nil,
        privateKeyPem: String,
        publicKeyPem: String,
        snSignature: [String: String],
        createdAt: String? = nil,
        updatedAt: String? = nil
    ) {
        self.bindToken = bindToken
        self.label = label
        self.privateKeyPem = privateKeyPem
        self.publicKeyPem = publicKeyPem
        self.snSignature = snSignature
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        bindToken = try container.decodeIfPresent(String.self, forKey: .bindToken) ?? ""
        label = try container.decodeIfPresent(String.self, forKey: .label)
        privateKeyPem = try container.decodeIfPresent(String.self, forKey: .privateKeyPem) ?? ""
        publicKeyPem = try container.decodeIfPresent(String.self, forKey: .publicKeyPem) ?? ""
        snSignature = try container.decodeIfPresent([String: String].self, forKey: .snSignature) ?? [:]
        createdAt = try container.decodeIfPresent(String.self, forKey: .createdAt)
        updatedAt = try container.decodeIfPresent(String.self, forKey: .updatedAt)
    }
}

public struct PlaudIdentity: Codable, Sendable {
    public var version: Int
    public var accounts: [String: PlaudAccount]

    public init(version: Int = 2, accounts: [String: PlaudAccount] = [:]) {
        self.version = version
        self.accounts = accounts
    }

    /// Serial numbers with a signature, excluding the wildcard entry.
    public var serials: [String] {
        let all = accounts.values.flatMap { $0.snSignature.keys }
        return Array(Set(all.filter { $0 != "*" })).sorted()
    }
}

public enum PlaudIdentityStore {
    /// Loads v2 (`{version, accounts}`) and migrates the old flat v1 account.
    public static func load(from url: URL) throws -> PlaudIdentity? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        let data: Data
        do {
            data = try Data(contentsOf: url)
        } catch {
            throw PlaudOnboardingError.storage("Datei nicht lesbar: \(error.localizedDescription)")
        }

        let decoder = JSONDecoder()
        if let identity = try? decoder.decode(PlaudIdentity.self, from: data) {
            return identity
        }
        if let account = try? decoder.decode(PlaudAccount.self, from: data) {
            let token = PlaudToken.normalize(account.bindToken)
            return PlaudIdentity(version: 2, accounts: [token: account])
        }
        throw PlaudOnboardingError.storage("Format der Identitätsdatei ist unbekannt")
    }

    /// Writes atomically and restricts the file to the current user (0600).
    public static func save(_ identity: PlaudIdentity, to url: URL) throws {
        do {
            try FileManager.default.createDirectory(
                at: url.deletingLastPathComponent(),
                withIntermediateDirectories: true,
                attributes: nil
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(identity)
            try data.write(to: url, options: .atomic)
            try FileManager.default.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
        } catch {
            throw PlaudOnboardingError.storage(error.localizedDescription)
        }
    }
}
