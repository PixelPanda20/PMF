import Foundation
import Security

/// A freshly generated RSA-2048 key pair in PEM form.
///
/// `SecKeyCopyExternalRepresentation` returns PKCS#1 for RSA, so the PEM labels
/// are `RSA PRIVATE KEY` / `RSA PUBLIC KEY`. Both Node (`crypto.createPrivateKey`)
/// and Python (`cryptography`) accept them, matching the reference identity file.
public struct PlaudKeyPair: Sendable {
    public let privateKeyPEM: String
    public let publicKeyPEM: String

    public init(privateKeyPEM: String, publicKeyPEM: String) {
        self.privateKeyPEM = privateKeyPEM
        self.publicKeyPEM = publicKeyPEM
    }
}

enum RSAKeyPair {
    static func generate(bits: Int = 2048) throws -> PlaudKeyPair {
        let attributes: [CFString: Any] = [
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits: bits,
            kSecPrivateKeyAttrs: [
                kSecAttrIsPermanent: false
            ] as [CFString: Any]
        ]

        var error: Unmanaged<CFError>?
        guard let privateKey = SecKeyCreateRandomKey(attributes as CFDictionary, &error) else {
            throw PlaudOnboardingError.keyGeneration(errorText(error))
        }
        guard let publicKey = SecKeyCopyPublicKey(privateKey) else {
            throw PlaudOnboardingError.keyGeneration("öffentlicher Schlüssel fehlt")
        }
        guard let privateData = SecKeyCopyExternalRepresentation(privateKey, &error) as Data? else {
            throw PlaudOnboardingError.keyGeneration(errorText(error))
        }
        guard let publicData = SecKeyCopyExternalRepresentation(publicKey, &error) as Data? else {
            throw PlaudOnboardingError.keyGeneration(errorText(error))
        }

        return PlaudKeyPair(
            privateKeyPEM: pem(privateData, label: "RSA PRIVATE KEY"),
            publicKeyPEM: pem(publicData, label: "RSA PUBLIC KEY")
        )
    }

    private static func pem(_ data: Data, label: String) -> String {
        let base64 = data.base64EncodedString(options: [.lineLength64Characters])
        return "-----BEGIN \(label)-----\n\(base64)\n-----END \(label)-----\n"
    }

    private static func errorText(_ error: Unmanaged<CFError>?) -> String {
        guard let error else { return "unbekannter Fehler" }
        return (error.takeRetainedValue() as Error).localizedDescription
    }
}
