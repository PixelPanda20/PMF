import Foundation

extension Data {
    /// Decodes standard or URL-safe base64, with or without padding.
    init?(base64URLEncoded string: String) {
        var value = string
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = value.count % 4
        if remainder > 0 {
            value += String(repeating: "=", count: 4 - remainder)
        }
        self.init(base64Encoded: value)
    }

    /// URL-safe base64 without padding (Fernet's token encoding).
    func base64URLEncodedString() -> String {
        base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}

/// The Plaud handshake expects the bind token padded to 32 characters.
public enum PlaudToken {
    public static func normalize(_ token: String) -> String {
        let trimmed = token.trimmingCharacters(in: .whitespacesAndNewlines)
        let prefix = String(trimmed.prefix(32))
        return prefix.count >= 32 ? prefix : prefix + String(repeating: "0", count: 32 - prefix.count)
    }

    public static func stripBearer(_ token: String) -> String {
        let trimmed = token.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.lowercased().hasPrefix("bearer ") {
            return String(trimmed.dropFirst(7)).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return trimmed
    }
}
