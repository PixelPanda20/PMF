import Foundation

struct PlaudAPIResponse {
    let body: [String: Any]
    let base: URL
}

/// Thin client for the Plaud device API used during onboarding.
struct PlaudAPI {
    let session: URLSession

    func post(
        _ path: String,
        payload: [String: Any],
        token: String,
        base: URL,
        redirects: Int = 0
    ) async throws -> PlaudAPIResponse {
        let endpoint = Self.url(base: base, path: path)
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 60
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("android", forHTTPHeaderField: "app-platform")
        request.setValue("1", forHTTPHeaderField: "X-Encrypt-Response")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        let result: (Data, URLResponse)
        do {
            result = try await session.data(for: request)
        } catch {
            throw PlaudOnboardingError.invalidResponse(
                "Plaud-API nicht erreichbar: \(error.localizedDescription)"
            )
        }
        let data = result.0
        let response = result.1

        guard let http = response as? HTTPURLResponse else {
            throw PlaudOnboardingError.invalidResponse("keine HTTP-Antwort")
        }
        if http.statusCode == 401 {
            throw PlaudOnboardingError.invalidToken
        }
        if http.statusCode >= 400 {
            throw PlaudOnboardingError.api(status: http.statusCode)
        }

        let encrypted = (http.value(forHTTPHeaderField: "x-encrypt-response") ?? "") == "1"
        let bodyData: Data
        if encrypted {
            let text = String(decoding: data, as: UTF8.self)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            bodyData = try Fernet.decrypt(text, key: PlaudOnboardingClient.appFernetKey)
        } else {
            bodyData = data
        }

        guard let json = try? JSONSerialization.jsonObject(with: bodyData) as? [String: Any] else {
            throw PlaudOnboardingError.invalidResponse("Antwort ist kein JSON")
        }

        let code = (json["code"] as? NSNumber)?.intValue ?? (json["status"] as? NSNumber)?.intValue
        if code == -302 {
            if let regionBase = Self.regionBase(from: json), redirects < 2, regionBase != base {
                return try await post(
                    path,
                    payload: payload,
                    token: token,
                    base: regionBase,
                    redirects: redirects + 1
                )
            }
            throw PlaudOnboardingError.invalidResponse("API verlangt eine andere Region")
        }
        if let code, code != 0 {
            throw PlaudOnboardingError.apiCode(code)
        }
        return PlaudAPIResponse(body: json, base: base)
    }

    private static func url(base: URL, path: String) -> URL {
        let clean = path.hasPrefix("/") ? String(path.dropFirst()) : path
        return base.appendingPathComponent(clean)
    }

    private static func regionBase(from body: [String: Any]) -> URL? {
        guard let data = body["data"] as? [String: Any] else { return nil }
        let domains = data["domains"] as? [String: Any]
        let candidate =
            domains?["api"] as? String
            ?? data["domain"] as? String
            ?? data["host"] as? String
            ?? data["base_url"] as? String
        guard let candidate, !candidate.isEmpty else { return nil }
        let value = candidate.hasPrefix("http") ? candidate : "https://\(candidate)"
        return URL(string: value)
    }
}
