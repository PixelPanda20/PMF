import Foundation

public struct PlaudProvisionResult: Sendable {
    /// The serial that was added/updated.
    public let serial: String
    /// Normalized bind token (the account key in the identity file).
    public let bindToken: String
    /// All serial numbers covered by the identity after the merge.
    public let serials: [String]
    /// The full identity as written to disk. Treat it as a secret.
    public let identity: PlaudIdentity

    public init(serial: String, bindToken: String, serials: [String], identity: PlaudIdentity) {
        self.serial = serial
        self.bindToken = bindToken
        self.serials = serials
        self.identity = identity
    }
}

/// One-time Plaud account onboarding.
///
/// Exchanges the `pld_ut` cookie of web.plaud.ai for the device identity
/// (per-serial SN signature + account-wide RSA-2048 key pair) and merges it into
/// an `identity.json` file. The token is used for this call only; the library
/// never stores or logs it.
///
/// The identity format matches `plaud-summarizer` and KOBY Translate, so the
/// file can be shared between the Mac app and those tools.
public final class PlaudOnboardingClient {
    /// Fernet key embedded in the Plaud Android app (for encrypted responses).
    public static let appFernetKey = "8rRmMCskL3NaUiGr-UsmEEeI8NKH-ZfeGbpRGqSLpuI="
    public static let defaultBaseURL = URL(string: "https://api.plaud.ai")!

    private let baseURL: URL
    private let session: URLSession

    public init(baseURL: URL = PlaudOnboardingClient.defaultBaseURL, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }

    /// Fetches the identity for `serial` and writes it to `identityURL`.
    ///
    /// - Parameters:
    ///   - userToken: `pld_ut` cookie value from web.plaud.ai (with or without
    ///     a leading `Bearer `).
    ///   - serial: device serial number, case-insensitive.
    ///   - bindToken: Plaud user id. Required for a new account; when the
    ///     identity file already contains exactly one account it may be omitted.
    ///   - identityURL: target `identity.json` (created with mode 0600).
    ///   - baseURL: optional API override (region), defaults to the client's.
    public func provision(
        userToken: String,
        serial: String,
        bindToken: String? = nil,
        identityURL: URL,
        baseURL: URL? = nil
    ) async throws -> PlaudProvisionResult {
        let token = PlaudToken.stripBearer(userToken)
        guard !token.isEmpty else { throw PlaudOnboardingError.tokenRequired }

        let normalizedSerial = serial.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalizedSerial.isEmpty else { throw PlaudOnboardingError.serialRequired }

        var identity = try PlaudIdentityStore.load(from: identityURL) ?? PlaudIdentity()

        let resolvedToken: String
        if let bindToken, !bindToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            resolvedToken = PlaudToken.normalize(bindToken)
        } else if identity.accounts.count == 1, let only = identity.accounts.keys.first {
            resolvedToken = only
        } else {
            throw PlaudOnboardingError.bindTokenRequired
        }
        let existing = identity.accounts[resolvedToken]

        let api = PlaudAPI(session: session)
        let apiBase = baseURL ?? self.baseURL

        let signResponse = try await api.post(
            "/device-app/device/sn-sign",
            payload: ["sns": [normalizedSerial]],
            token: token,
            base: apiBase
        )
        guard
            let data = signResponse.body["data"] as? [String: Any],
            let signatures = data["signature"] as? [String: Any],
            let signature = signatures[normalizedSerial] as? String,
            !signature.isEmpty
        else {
            throw PlaudOnboardingError.invalidResponse(
                "keine Signatur für \(normalizedSerial)"
            )
        }

        // The RSA key pair is account-wide and reused across devices. Only
        // generate a new one when the identity has none yet.
        var privateKeyPEM = existing?.privateKeyPem ?? ""
        var publicKeyPEM = existing?.publicKeyPem ?? ""
        if privateKeyPEM.isEmpty {
            let keyResponse = try await api.post(
                "/device-app/e2ee/gen_key",
                payload: [:],
                token: token,
                base: signResponse.base
            )
            guard
                let keyData = keyResponse.body["data"] as? [String: Any],
                let privateBase64 = keyData["private_key_base64"] as? String,
                let publicBase64 = keyData["public_key_base64"] as? String,
                let privateData = Data(base64Encoded: privateBase64),
                let publicData = Data(base64Encoded: publicBase64),
                let privatePEM = String(data: privateData, encoding: .utf8)
            else {
                throw PlaudOnboardingError.invalidResponse("kein Schlüsselpaar")
            }
            privateKeyPEM = privatePEM
            publicKeyPEM = String(data: publicData, encoding: .utf8) ?? ""
        }

        let now = ISO8601DateFormatter().string(from: Date())
        var account =
            existing
            ?? PlaudAccount(
                bindToken: resolvedToken,
                label: "Plaud-Konto",
                privateKeyPem: privateKeyPEM,
                publicKeyPem: publicKeyPEM,
                snSignature: [:],
                createdAt: now,
                updatedAt: now
            )
        account.bindToken = resolvedToken
        account.privateKeyPem = privateKeyPEM
        account.publicKeyPem = publicKeyPEM
        account.snSignature[normalizedSerial] = signature
        account.createdAt = account.createdAt ?? now
        account.updatedAt = now
        identity.accounts[resolvedToken] = account

        try PlaudIdentityStore.save(identity, to: identityURL)

        return PlaudProvisionResult(
            serial: normalizedSerial,
            bindToken: resolvedToken,
            serials: identity.serials,
            identity: identity
        )
    }
}
