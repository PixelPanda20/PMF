import Foundation

/// Errors surfaced by the onboarding flow. Messages are user-facing and never
/// contain tokens or key material.
public enum PlaudOnboardingError: Error, LocalizedError, Equatable {
    case tokenRequired
    case serialRequired
    case bindTokenRequired
    case invalidToken
    case api(status: Int)
    case apiCode(Int)
    case invalidResponse(String)
    case decryption(String)
    case keyGeneration(String)
    case storage(String)

    public var errorDescription: String? {
        switch self {
        case .tokenRequired:
            return "Plaud-Token fehlt (pld_ut-Cookie von web.plaud.ai)."
        case .serialRequired:
            return "Seriennummer fehlt."
        case .bindTokenRequired:
            return "Bind-Token erforderlich – er ist die Plaud-Benutzer-ID, nicht die Seriennummer."
        case .invalidToken:
            return "Plaud-Token ungültig oder abgelaufen (pld_ut-Cookie von web.plaud.ai)."
        case .api(let status):
            return "Plaud-API antwortete mit HTTP \(status)."
        case .apiCode(let code):
            return "Plaud-API-Fehler \(code)."
        case .invalidResponse(let detail):
            return "Plaud-Antwort unerwartet: \(detail)"
        case .decryption(let detail):
            return "Verschlüsselte Plaud-Antwort nicht lesbar: \(detail)"
        case .keyGeneration(let detail):
            return "RSA-Schlüssel konnte nicht erzeugt werden: \(detail)"
        case .storage(let detail):
            return "Identität konnte nicht gespeichert werden: \(detail)"
        }
    }
}
