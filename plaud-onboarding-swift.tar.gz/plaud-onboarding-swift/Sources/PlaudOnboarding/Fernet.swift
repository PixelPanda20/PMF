import CommonCrypto
import CryptoKit
import Foundation

/// Fernet (AES-128-CBC + HMAC-SHA256) as used for encrypted Plaud responses.
///
/// Token layout: version (0x80) | timestamp (8) | IV (16) | ciphertext | HMAC (32).
/// The 32-byte Fernet secret is split into a 16-byte signing key and a 16-byte
/// encryption key.
enum Fernet {
    static func decrypt(_ token: String, key: String) throws -> Data {
        guard let raw = Data(base64URLEncoded: token), raw.count >= 1 + 8 + 16 + 32,
              raw.first == 0x80
        else {
            throw PlaudOnboardingError.decryption("Token ist ungültig")
        }
        guard let secret = Data(base64URLEncoded: key), secret.count == 32 else {
            throw PlaudOnboardingError.decryption("Schlüssel ist ungültig")
        }

        let signingKey = Data(secret.prefix(16))
        let encryptionKey = Data(secret.suffix(16))
        let signature = Data(raw.suffix(32))
        let signed = Data(raw.dropLast(32))

        let expected = Data(
            HMAC<SHA256>.authenticationCode(
                for: signed,
                using: SymmetricKey(data: signingKey)
            )
        )
        guard constantTimeEquals(expected, signature) else {
            throw PlaudOnboardingError.decryption("Signatur stimmt nicht")
        }

        let iv = Data(raw[9..<25])
        let ciphertext = Data(raw[25..<(raw.count - 32)])
        return try aesCBCDecrypt(key: encryptionKey, iv: iv, ciphertext: ciphertext)
    }

    private static func aesCBCDecrypt(key: Data, iv: Data, ciphertext: Data) throws -> Data {
        var output = Data(count: ciphertext.count + kCCBlockSizeAES128)
        var outputLength = 0

        let status = output.withUnsafeMutableBytes { outputPtr -> CCCryptorStatus in
            ciphertext.withUnsafeBytes { ciphertextPtr -> CCCryptorStatus in
                key.withUnsafeBytes { keyPtr -> CCCryptorStatus in
                    iv.withUnsafeBytes { ivPtr -> CCCryptorStatus in
                        CCCrypt(
                            CCOperation(kCCDecrypt),
                            CCAlgorithm(kCCAlgorithmAES),
                            CCOptions(0),
                            keyPtr.baseAddress,
                            key.count,
                            ivPtr.baseAddress,
                            ciphertextPtr.baseAddress,
                            ciphertext.count,
                            outputPtr.baseAddress,
                            outputPtr.count,
                            &outputLength
                        )
                    }
                }
            }
        }

        guard status == kCCSuccess else {
            throw PlaudOnboardingError.decryption("AES-Entschlüsselung fehlgeschlagen")
        }
        return Data(output.prefix(outputLength))
    }

    private static func constantTimeEquals(_ lhs: Data, _ rhs: Data) -> Bool {
        guard lhs.count == rhs.count else { return false }
        var difference: UInt8 = 0
        for (left, right) in zip(lhs, rhs) {
            difference |= left ^ right
        }
        return difference == 0
    }
}
