// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PlaudOnboarding",
    platforms: [
        .macOS(.v12)
    ],
    products: [
        .library(name: "PlaudOnboarding", targets: ["PlaudOnboarding"]),
        .executable(name: "plaud-onboard", targets: ["plaud-onboard"])
    ],
    targets: [
        .target(name: "PlaudOnboarding"),
        .executableTarget(name: "plaud-onboard", dependencies: ["PlaudOnboarding"]),
        .testTarget(name: "PlaudOnboardingTests", dependencies: ["PlaudOnboarding"])
    ]
)
